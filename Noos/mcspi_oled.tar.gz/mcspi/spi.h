#ifndef  __SPI_H__
#define  __SPI_H__

#define McSPI_DATA_COUNT            256 // Data Count Transaction




unsigned char    rxBuffer[McSPI_DATA_COUNT + 10];


unsigned int s_ok,r_ok;

extern void spi_init(void);
extern unsigned char SPIRecvByte(void);


#if 1
extern void  delay(unsigned int   i);

extern void spi1_irq(void);
extern void spi_init(void);
extern void SPISendByte(unsigned char val);
extern void debug_spi(char *str);
#endif




#endif

#if 0

#define MCSPI_INT_TX_EMPTY(chan)     ((uint32_t)                               \
                                      MCSPI_IRQENABLE_TX0_EMPTY_ENABLE_MASK << \
                                      ((chan) * 4))
                                      
#define MCSPI_IRQENABLE_TX0_EMPTY_ENABLE_MASK                                                               ((uint32_t)0x00000001U)



#define MCSPI_IRQENABLE_TX0_UNDERFLOW_ENABLE_MASK                                                           ((uint32_t)0x00000002U)

#define MCSPI_INT_TX_UNDERFLOW(chan) ((uint32_t)                                \
                                      MCSPI_IRQENABLE_TX0_UNDERFLOW_ENABLE_MASK \
                                      << ((chan) * (uint32_t) 4))

#define MCSPI_INT_RX_FULL(chan)      ((uint32_t)                              \
                                  MCSPI_IRQENABLE_RX0_FULL_ENABLE_MASK << \
                                      ((chan) * 4))
#define MCSPI_INT_RX0_OVERFLOW       ((uint32_t) \
										  MCSPI_IRQSTATUS_RX0_OVERFLOW_MASK)

#define MCSPI_IRQENABLE_RX0_FULL_ENABLE_SHIFT                                                               ((uint32_t)2U)
#define MCSPI_IRQENABLE_RX0_FULL_ENABLE_MASK                                                                ((uint32_t)0x00000004U)
#define MCSPI_IRQENABLE_RX0_FULL_ENABLE_IRQDISABLED                                                          ((uint32_t)0U)
#define MCSPI_IRQENABLE_RX0_FULL_ENABLE_IRQENABLED                                                           ((uint32_t)1U)
#define MCSPI_IRQSTATUS_RX0_OVERFLOW_SHIFT                                                                  ((uint32_t)3U)
#define MCSPI_IRQSTATUS_RX0_OVERFLOW_MASK                                                                   ((uint32_t)0x00000008U)
#define MCSPI_IRQSTATUS_RX0_OVERFLOW_NOEVNT_R                                                                ((uint32_t)0U)
#define MCSPI_IRQSTATUS_RX0_OVERFLOW_EVNT_R                                                                  ((uint32_t)1U)


#endif




