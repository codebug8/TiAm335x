
#ifndef  __LED_H__
#define  __LED_H__

extern void led_init(void);
#if 0
extern void led_switch(unsigned char on_off);
extern void led0_switch(unsigned char on_off);
extern void led1_switch(unsigned char on_off);
extern void led2_switch(unsigned char on_off);
extern void led3_switch(unsigned char on_off);
#endif
#endif


