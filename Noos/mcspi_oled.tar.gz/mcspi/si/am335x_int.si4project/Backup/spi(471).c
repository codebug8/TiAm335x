#include "AM335X_SOC.h"
#include "spi.h"
#include "uart.h"
#include "printf.h"
#include "interrupt.h" 



uint32_t		  length = 0;
unsigned char	 txBuffer[McSPI_DATA_COUNT + 10];

/*********************************************************************************
   *Function:     delay
   *Description： 简单延时
   *Input:        循环次数
   *Output:       \
   *Return:       0
   *Others:       1500000约等于1s;
**********************************************************************************/
void  delay(unsigned int   i)
{
	volatile unsigned int count = i;
	volatile unsigned int temp = 5;
	
	for(; count > 0; count--)
		for(;temp>0;temp--);
}

void SPISendByte(unsigned char val)
 {			 

	      
 	//通道0使能
	McSPI1->CH0CTRL = 0x1;
	
	printf("spi send data: 0x%x\n\r", val);
 	McSPI1->TX0 = val;
	
	 while (!(McSPI1->CH0STAT & (1 << 2)))
	{
		 printf("wait .... McSPI1->CH0STAT -->> 	  = 0x%x\r\n",McSPI1->CH0STAT);   
	 }
	
	//通道0禁止
 	McSPI1->CH0CTRL = 0x0; 
	 
 }



void McSPIIsr(void)
	{


	}


void spi1_gpio_init(void)
{




	CM_PER_SPI1_CLKCTRL |= (0x2 << 0);
	CM_PER_SPI1_CLKCTRL &= ~(0x3 << 16);
	printf("CM_PER_SPI1_CLKCTRL -->>		 = 0x%x\r\n",CM_PER_SPI1_CLKCTRL);

	CM_PER_GPIO3_CLKCTRL  |= (0x02<<0  | 0x1 << 18);
	CM_PER_GPIO3_CLKCTRL &= ~(0x3 << 16);
	
	printf("CM_PER_GPIO3_CLKCTRL -->>		 = 0x%x\r\n",CM_PER_GPIO3_CLKCTRL);
	CM_PER_L4LS_CLKSTCTRL |= (0x01<<25 | 0x1 << 21);	
	//CM_PER_L4LS_CLKSTCTRL &= ~(0x3 <<0);
	printf("CM_PER_L4LS_CLKSTCTRL -->> 	 = 0x%x\r\n",CM_PER_L4LS_CLKSTCTRL);
	


	CONF_MCASP0_FSX    &= ~(0x7 << 0); 
	CONF_MCASP0_FSX    |= (0x3 << 0);
	CONF_MCASP0_ACLKX	 &= ~(0x7 << 0); 
	CONF_MCASP0_ACLKX	 |= (0x3 << 0);
	CONF_MCASP0_AHCLKR	 &= ~(0x7 << 0); 
	CONF_MCASP0_AHCLKR	|= (0x3 << 0);

	printf("CONF_MCASP0_FSX -->>	 = 0x%x\r\n",CONF_MCASP0_FSX);
	printf("CONF_MCASP0_ACLKX -->>	 = 0x%x\r\n",CONF_MCASP0_ACLKX);
	printf("CONF_MCASP0_AHCLKR -->>	 = 0x%x\r\n",CONF_MCASP0_AHCLKR);


	//操作oled 不使用接收功能引脚，设置为普通gpio用作oled DC引脚 gpio3_16
	//D1作为GPIO
	CONF_MCASP0_AXR0 |= (0x7 <<0 );
	printf("CONF_MCASP0_AXR0 -->>  = 0x%x\r\n",CONF_MCASP0_AXR0);

	GPIO3_OE	   &= ~(0x01<<16);//输出
		printf("GPIO3_OE -->>  = 0x%x\r\n",GPIO3_OE);
	GPIO3_DATAOUT |=  (0x01<<16);//拉高
		printf("GPIO3_DATAOUT -->>  = 0x%x\r\n",GPIO3_DATAOUT);

	

}

 void spi_init(void)
  {
	
	printf("PRCM_CM_PER_SPI1_CLKCTRL send  -->>	   = 0x%x\r\n",CM_PER_SPI1_CLKCTRL);
	printf("PRCM_CM_PER_L4LS_CLKSTCTRL send-->>	   = 0x%x\r\n",CM_PER_L4LS_CLKSTCTRL);	 
	 /*spi1中断初始化*/  
	 spi1_gpio_init();		  
	 IntSystemEnable(McSPI1INT);
	 register_irq(McSPI1INT, McSPIIsr); 	  
	 interrupt_init(McSPI1INT,0,0);
	  

  
	   
	   /*McSPIReset 		   
	   *McSPICSEnable		   
	   *McSPIMasterModeEnable  
	   *McSPIMasterModeConfig  
	   *					   
	   *McSPIClkConfig		   
	   *McSPIWordLengthSet	   
	   *McSPICSPolarityConfig  
	   *McSPITxFIFOConfig	   
	   *McSPIRxFIFOConfig	   
	   */
	   
		   
		//软件复位操作
	McSPI1->SYSCONFIG  |= (0x1 << 1 ); 
	  
	printf("McSPI1->SYSCONFIG    = 0x%x\r\n",McSPI1->SYSCONFIG   );	  
	while(!(McSPI1->SYSSTS & (0x01<<0)));//1h (R) = Reset completed 
	  
	//值为1表示复位完成
	printf("McSPI1->SYSSTS-->>	   = 0x%x\r\n",McSPI1->SYSSTS );
	  
	/*模块配置
	*（a）写入MCSPI_MODULCTRL
	*（b）写入MCSPI_SYSCONFIG。
	*/
		  
	McSPI1->MODULCTRL &= ~(0x1 << 1); //bit 1 4PIN mode
	McSPI1->MODULCTRL &= ~(0x1 << 2); //master mode
	
	McSPI1->MODULCTRL |= (0x1 << 0); // Only one channel will be used in master mode.  
	printf("McSPI1->MODULCTRL-->>	   = 0x%x\r\n",McSPI1->MODULCTRL );
			 
	//默认为发送和接受模式，所以下面不做设置
	// McSPI1->CH0CONF &= ~( 0x3 << 12);	// Transmit and Receive mode

	//默认是 DAT1 作为输入 DAT0作为输出
	McSPI1->CH0CONF &= ~( 0x1 << 16); //D0 output  D1 intput
//	McSPI1->CH0CONF |= ( 0x2 << 12);	// Transmit only mode


	//配置分频系数
	McSPI1->CH0CONF  &= ~(0x1 << 29 ); //
	McSPI1->CH0CONF  |= (0x1 << 2 ); //2 rate 24Mhz


	//配置时钟模式

	/* OLED  is  mode 4  */

	McSPI1->CH0CONF  |= (0x1 << 1 ); //pclk mode
	McSPI1->CH0CONF  |= (0x1 << 1);
				  			


	McSPI1->CH0CONF  |= (0x7 << 7 ); //McSPIWordLengthSet  8bit	  
	McSPI1->CH0CONF  |= (0x1 << 6 ); //1h (R/W) = SPIEN is held low during the active state.

	//McSPI1->CH0CONF  |= (0x1 << 23 ); //Start bit enable for SPI transfe
					  
	printf("McSPI1->CH0CONF-->>	   = 0x%x\r\n",McSPI1->CH0CONF );
 
   
 }


 
 unsigned char SPIRecvByte(void)
 
 {
	 unsigned char data;
 
 //  printf("spi send data: 0x%x, STATUS before send 0xff: 0x%x\n\r", data, McSPI2->CH0STAT);
 
	 //接受寄存器为满的时候发送 直到为空则 返回 val值
	 McSPI1->TX0 = 0xff;
	 
	  while (!(McSPI1->CH0STAT & (1 << 1)))
	 {
		  printf("wait for recv .... McSPI1->CH0STAT -->>	   = 0x%x\r\n",McSPI1->CH0STAT);   
	  }
	  
	 data  = McSPI1->RX0;
					 
	 
	 return data;
 
 }
 
