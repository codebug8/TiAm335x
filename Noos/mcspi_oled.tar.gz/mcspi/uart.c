#include "AM335X_SOC.h"


void  uart0_clock_enable()
{
	volatile unsigned  int  temp=0;
	
	CM_WKUP_UART0_CLKCTRL |=  (0x2);

	do
	{
		temp =  CM_WKUP_CLKSTCTRL;
	}
	while((0x1<<12) !=  (temp  &  (0x1<<12) ));
		
	do
	{
		temp =  CM_WKUP_UART0_CLKCTRL;
	}
	while((0x0<<16) !=  (temp  &  (0x3<<16) ));
	
}


void  uart0_iomux()
{
	//unsigned  int  temp=0;

	CONF_UART0_TXD =  ((0x0 << 0) | (0X0 << 3 ));
	CONF_UART0_RXD =  ((0x0 << 0 )| (0X1 << 4 )|( 0x1 << 5)) ;

}


void  uart0_config()
{	
	unsigned  int  temp=0;
	//unsigned  int  enhanced_en_val=0;
		

	UART0_SYSC |= (1<<1);
	do
	{
		temp =  UART0_SYSS;
	}
	while( !(temp & (0x1)) );


	UART0_LCR   = 0x0;	
	UART0_FCR   = 0X0;
	
	UART0_MDR1 |= (0x7);
	UART0_LCR   = 0x00bf;


	UART0_EFR  |= (0x1<<4);
	UART0_LCR   = 0x0;	
	
	UART0_IER_UART  &=~(1<<4);


	UART0_LCR   = 0x00bf;


	UART0_DLH = ( 0 & 0X3F);
	UART0_DLL = (26 & 0XFF);	


	UART0_EFR  &= ~(0x1<<4);

	UART0_LCR  = (3<<0);
	
	UART0_MDR1 &= ~(0x7);
	
}


void  uart_init()
{
	uart0_clock_enable();

	uart0_iomux();

	uart0_config();

}


void  uart_PutChar(char  c)
{
	while( (1<<6) !=( UART0_LSR_UART & (1<<6) ));
	
	UART0_THR = (c & 0XFF);	
	
}


void uart_PutString(char *ptr)
{
	 
	while(*ptr != '\0')
	{          
		uart_PutChar(*ptr++);
	}
	uart_PutChar('\r');
	uart_PutChar('\n');
}

