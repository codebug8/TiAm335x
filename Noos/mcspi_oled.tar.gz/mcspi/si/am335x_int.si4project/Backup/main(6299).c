﻿#include "AM335X_SOC.h"
#include "uart.h"
#include "spi.h"
#include "oled.h"
#include "printf.h"


void mdelay(int times);
int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val);



void mdelay(int times)
{
	volatile int i, j;
	for(j = 0 ; j < times; j++ )
		{	for(i=0; i < 100000; i++ );
			i = i+1;
		}
}

int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val)
{
	volatile unsigned  int  reg=reg_addr;	
	unsigned  int  tmp=0;//volatile unsigned  int  tmp=0;
	
	do
	{
		tmp = reg;
		tmp = tmp & (bits); 
	}
	while(expected_val !=  tmp);//判断

	return 0;
}

	





int main()
{
  
    
    uart_init();   // 波特率115200，8N1(8个数据位，无校验位，1个停止位)
		
	gic_init();
	spi_init();
    OLEDInit();
    OLEDPrint(0,0,"www.100ask.net, 100ask.taobao.com");
    
    
    while (1)
    {
        
      // printf("Enter your selection: \r\n");

      
    	}
    return 0;
}
