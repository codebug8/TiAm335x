#include "AM335X_SOC.h"
#include "led.h"
#include "delay.h"
#include "uart.h"
#include "printf.h"


int  main()
{
//	led_init();
	uart_init();

	printf("uart  init.\n\r");
	
	while(1);
	
}
