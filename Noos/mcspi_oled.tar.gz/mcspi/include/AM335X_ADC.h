#ifndef _AM335X_ADC_H_
#define _AM335X_ADC_H_
#include "AM335X_Mapping.h"

typedef struct {   
	uint32_t  REVISION;						//0h  
uint32_t RESERVED0[3];  		  //4h
	uint32_t  SYSCONFIG;                    //10h 
uint32_t RESERVED1[4];  		  //14h
	uint32_t  IRQSTATUS_RAW;                //24h 
	uint32_t  IRQSTATUS;                    //28h 
	uint32_t  IRQENABLE_SET;                //2Ch 
	uint32_t  IRQENABLE_CLR;                //30h 
	uint32_t  IRQWAKEUP;                    //34h 
	uint32_t  DMAENABLE_SET;                //38h 
	uint32_t  DMAENABLE_CLR;                //3Ch 
	uint32_t  CTRL;                         //40h 
	uint32_t  ADCSTAT;                      //44h 
	uint32_t  ADCRANGE;                     //48h 
	uint32_t  ADC_CLKDIV;                   //4Ch 
	uint32_t  ADC_MISC;                     //50h 
	uint32_t  STEPENABLE;                   //54h 
	uint32_t  IDLECONFIG;                   //58h 
	uint32_t  TS_CHARGE_STEPCONFIG;         //5Ch 
	uint32_t  TS_CHARGE_DELAY;              //60h 
	uint32_t  STEPCONFIG1;                  //64h 
	uint32_t  STEPDELAY1;                   //68h 
	uint32_t  STEPCONFIG2;                  //6Ch 
	uint32_t  STEPDELAY2;                   //70h 
	uint32_t  STEPCONFIG3;                  //74h 
	uint32_t  STEPDELAY3;                   //78h 
	uint32_t  STEPCONFIG4;                  //7Ch 
	uint32_t  STEPDELAY4;                   //80h 
	uint32_t  STEPCONFIG5;                  //84h 
	uint32_t  STEPDELAY5;                   //88h 
	uint32_t  STEPCONFIG6;                  //8Ch 
	uint32_t  STEPDELAY6;                   //90h 
	uint32_t  STEPCONFIG7;                  //94h 
	uint32_t  STEPDELAY7;                   //98h 
	uint32_t  STEPCONFIG8;                  //9Ch 
	uint32_t  STEPDELAY8;                   //A0h 
	uint32_t  STEPCONFIG9;                  //A4h 
	uint32_t  STEPDELAY9;                   //A8h 
	uint32_t  STEPCONFIG10;                 //ACh 
	uint32_t  STEPDELAY10;                  //B0h 
	uint32_t  STEPCONFIG11;                 //B4h 
	uint32_t  STEPDELAY11;                  //B8h 
	uint32_t  STEPCONFIG12;                 //BCh 
	uint32_t  STEPDELAY12;                  //C0h 
	uint32_t  STEPCONFIG13;                 //C4h 
	uint32_t  STEPDELAY13;                  //C8h 
	uint32_t  STEPCONFIG14;                 //CCh 
	uint32_t  STEPDELAY14;                  //D0h 
	uint32_t  STEPCONFIG15;                 //D4h 
	uint32_t  STEPDELAY15;                  //D8h 
	uint32_t  STEPCONFIG16;                 //DCh 
	uint32_t  STEPDELAY16;                  //E0h 
	uint32_t  FIFO0COUNT;                   //E4h 
	uint32_t  FIFO0THRESHOLD;               //E8h 
	uint32_t  DMA0REQ;                      //ECh 
	uint32_t  FIFO1COUNT;                   //F0h 
	uint32_t  FIFO1THRESHOLD;               //F4h 
	uint32_t  DMA1REQ;                      //F8h 
uint32_t RESERVED3[1];  		  //FCh
	uint32_t  FIFO0DATA;                    //100h
uint32_t RESERVED4[63];  		  //104h
	uint32_t  FIFO1DATA;                    //200h
	}ADC_Typedef;



#define   ADC	    ((ADC_Typedef *)ADC_TSC)  
//ADC0_Typedef * ADC0 = ((ADC0_Typedef *) ADC0_BASE);
//(ADC0_Typedef *)ADC0_BASE->SYSCONFIG
#define   ADC_DMA  	((ADC_Typedef *)ADC_TSC_DMA)  



#endif





