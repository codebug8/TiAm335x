#include "AM335X_SOC.h"
#include "oled.h"
#include "oledfont.h"  	 
#include "spi.h"
#include "printf.h"


static void OLED_Set_DC(char val)
{
	if(val)
	{
		GPIO3_DATAOUT |=  (0x01<<16);
	
	}
	else 
	
	GPIO3_DATAOUT &= ~(0x01<<16);
	
	//printf("GPIO3->DATAOUT  ++oled -->>	  = 0x%x\r\n",GPIO3_DATAOUT);

	
}

/*
*片选引脚由高电平变为低电平表示选中
*D0 引脚配置为发送模式
*GPIO3_16配置为DC功能引脚
*/
/* bit 20
手动SPIEN断言在SPI字之间保持SPIEN有效。
（仅限单通道主模式）

0h（R / W）=当MCSPI_CHCONF（i）[EPOL] = 0时向该位写入0将SPIEN线驱动为低电平，当MCSPI_CHCONF（i）[EPOL] = 1时将其驱动为高电平。

1h（R / W）=当MCSPI_CHCONF（i）[EPOL] = 0时，向该位写入1将驱动SPIEN线，当MCSPI_CHCONF（i）[EPOL] = 1时将其驱动为低电平

*/
static void OLED_Set_CS(char val)
{
	if (val)
       McSPI1->CH0CONF  &= ~(0x1 << 20 ); 	
	
    else
  
      McSPI1->CH0CONF  |=  (0x1 << 20);
	  
	//printf("McSPI2->CH0CONF  ++oled -->>	  = 0x%x\r\n",McSPI0->CH0CONF);

}

#if 0

 if(val) {
	GPIO3->DATAOUT |=  (0x01<<25);
} 
else {
	GPIO3->DATAOUT &= ~(0x01<<25);

#endif


static void OLEDWriteCmd(unsigned char cmd)
{
    OLED_Set_DC(0); /* command */
    OLED_Set_CS(0); /* select OLED */

    spi_send_byte(cmd);

    OLED_Set_CS(1); /* de-select OLED */
    OLED_Set_DC(1); /*  */
}

static void OLEDWriteDat(unsigned char dat)
{
    OLED_Set_DC(1); /* data */
    OLED_Set_CS(0); /* select OLED */

    spi_send_byte(dat);

    OLED_Set_CS(1); /* de-select OLED */
    OLED_Set_DC(1); /*  */
}

static void OLEDSetPageAddrMode(void)
{
    OLEDWriteCmd(0x20);
    OLEDWriteCmd(0x02);
}

static void OLEDSetPos(int page, int col)
{
    OLEDWriteCmd(0xB0 + page); /* page address */

    OLEDWriteCmd(col & 0xf);   /* Lower Column Start Address */
    OLEDWriteCmd(0x10 + (col >> 4));   /* Lower Higher Start Address */
}


static void OLEDClear(void)
{
    int page, i;
    for (page = 0; page < 8; page ++)
    {
        OLEDSetPos(page, 0);
        for (i = 0; i < 128; i++)
            OLEDWriteDat(0);
    }
}

void OLEDInit(void)
{
    /* 向OLED发命令以初始化 */
    OLEDWriteCmd(0xAE); /*display off*/ 
    OLEDWriteCmd(0x00); /*set lower column address*/ 
    OLEDWriteCmd(0x10); /*set higher column address*/ 
    OLEDWriteCmd(0x40); /*set display start line*/ 
    OLEDWriteCmd(0xB0); /*set page address*/ 
    OLEDWriteCmd(0x81); /*contract control*/ 
    OLEDWriteCmd(0x66); /*128*/ 
    OLEDWriteCmd(0xA1); /*set segment remap*/ 
    OLEDWriteCmd(0xA6); /*normal / reverse*/ 
    OLEDWriteCmd(0xA8); /*multiplex ratio*/ 
    OLEDWriteCmd(0x3F); /*duty = 1/64*/ 
    OLEDWriteCmd(0xC8); /*Com scan direction*/ 
    OLEDWriteCmd(0xD3); /*set display offset*/ 
    OLEDWriteCmd(0x00); 
    OLEDWriteCmd(0xD5); /*set osc division*/ 
    OLEDWriteCmd(0x80); 
    OLEDWriteCmd(0xD9); /*set pre-charge period*/ 
    OLEDWriteCmd(0x1f); 
    OLEDWriteCmd(0xDA); /*set COM pins*/ 
    OLEDWriteCmd(0x12); 
    OLEDWriteCmd(0xdb); /*set vcomh*/ 
    OLEDWriteCmd(0x30); 
    OLEDWriteCmd(0x8d); /*set charge pump enable*/ 
    OLEDWriteCmd(0x14); 

    OLEDSetPageAddrMode();

    OLEDClear();
    
    OLEDWriteCmd(0xAF); /*display ON*/    
}


/* page: 0-7
 * col : 0-127
 * 字符: 8x16象素
 */
void OLEDPutChar(int page, int col, char c)
{
    int i = 0;
    /* 得到字模 */
    const unsigned char *dots = oled_asc2_8x16[c - ' '];

    /* 发给OLED */
    OLEDSetPos(page, col);
    /* 发出8字节数据 */
    for (i = 0; i < 8; i++)
        OLEDWriteDat(dots[i]);

    OLEDSetPos(page+1, col);
    /* 发出8字节数据 */
    for (i = 0; i < 8; i++)
        OLEDWriteDat(dots[i+8]);

}


/* page: 0-7
 * col : 0-127
 * 字符: 8x16象素
 */
void OLEDPrint(int page, int col, char *str)
{
    int i = 0;
    while (str[i])
    {
        OLEDPutChar(page, col, str[i]);
        col += 8;
        if (col > 127)
        {
            col = 0;
            page += 2;
        }
        i++;
    }
}

void OLEDClearPage(int page)
{
    int i;
    OLEDSetPos(page, 0);
    for (i = 0; i < 128; i++)
        OLEDWriteDat(0);    
}  