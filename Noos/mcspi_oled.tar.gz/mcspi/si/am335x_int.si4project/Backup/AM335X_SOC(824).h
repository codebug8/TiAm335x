#ifndef _SOC_AM335X_H_
#define _SOC_AM335X_H_

#include  "AM335X_Mapping.h"
#include  "AM335X_CLock_Module.h"
#include  "AM335X_Control.h"
#include  "AM335X_GPIO.h"
#include  "AM335X_Uart.h"
#include  "AM335X_Timer.h"
#include  "AM335X_INT.h"
#include  "AM335X_ADC.h"

/**
#include  "AM335X_PWM.h"
#include  "AM335X_HDQ1W.h"
#include  "AM335X_DSS.h"
#include  "AM335X_MMC.h"
**/
#endif

