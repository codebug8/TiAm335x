#include "AM335X_SOC.h"
#include "printf.h"
#include "interrupt.h"


static irq_func g_irq_func_array[128];

/**************** *************************************************************
**                 STATIC VARIABLE DEFINITIONS
******************************************************************************/
void (*fnRAMVectors[128])(void);





/**
 * The Default Interrupt Handler.
 *
 * This is the default interrupt handler for all interrupts. It simply returns
 * without performing any operation.
 **/
static void IntDefaultHandler(void)
{
    /* Go Back. Nothing to be done */
    ;
}

void gic_init(void)
{
    unsigned int irq;

    /* Reset the ARM interrupt controller */
    INTC_SYSCONFIG = 0x2;
 
    /* Wait for the reset to complete */
    while ((INTC_SYSSTATUS  & 0x1) != 0x1);    
  
    /* Enable any interrupt generation by setting priority threshold */ 
   INTC_THRESHOLD =  INTC_THRESHOLD_PRIORITYTHRESHOLD;
//	printf("INTC_THRESHOLD = %d\r\n",INTC_THRESHOLD  );


	//INTC_IDLE  |= ( 0x1  << 1 |0x1 << 0);
	
	/* Register the default handler for all interrupts */
	for (irq = 0;  irq < 128; irq++)
	{
		 fnRAMVectors[irq] = IntDefaultHandler;
	}

}

void IntSystemEnable(int irq)
{
  //  __asm(" dsb");
    
    /* Disable the system interrupt in the corresponding MIR_CLEAR register */
   INTC_MIR_CLEAR(irq >> 0x05)  = (0x01 << (irq & 0x1f));
	printf("IntSystemEnable: %d\n\r", irq);
}





void interrupt_init(int irq,unsigned int priority, unsigned int hostIntRoute)
{

	//设置中断号的极性以及
	INTC_ILR(irq) =((priority << 0x2) & 0x1fc) | hostIntRoute ;

	printf("interrupt_init is ok ! \r\n");

}



void register_irq(int irq, irq_func func)
{
	
	printf("register_irq: %d.\n\r", irq);

	if (irq > 0 && irq < 128)
		{
		g_irq_func_array[irq] = func;
		}

	
}




 int getirq(void)
 {
	 return ( INTC_SIR_IRQ &  0x7f);
 }




void enable_new_irq(void)
{
	INTC_CONTROL = 1;
}

void do_irq(int lr)
{
	int irq = getirq();
		
	printf("get_irq: %d, lr = 0x%x\n\r", irq, lr);
	if (g_irq_func_array[irq])
	{
		g_irq_func_array[irq]();
	}

	enable_new_irq();
	
}


