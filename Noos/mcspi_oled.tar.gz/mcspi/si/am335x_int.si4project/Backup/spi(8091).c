#include "AM335X_SOC.h"
#include "spi.h"
#include "uart.h"
#include "printf.h"
#include "interrupt.h" 



uint32_t		  length = 0;
unsigned char	 txBuffer[McSPI_DATA_COUNT + 10];

/*********************************************************************************
   *Function:     delay
   *Description： 简单延时
   *Input:        循环次数
   *Output:       \
   *Return:       0
   *Others:       1500000约等于1s;
**********************************************************************************/
void  delay(unsigned int   i)
{
	volatile unsigned int count = i;
	volatile unsigned int temp = 5;
	
	for(; count > 0; count--)
		for(;temp>0;temp--);
}

void spi_send_byte(unsigned char val)
 {			 

	      
 	//通道0使能
	McSPI0->CH0CTRL = 0x1;
	
	printf("spi send data: 0x%x\n\r", val);
 	McSPI0->TX0 = val;
	
	 while (!(McSPI0->CH0STAT & (1 << 2)))
	{
		 printf("wait .... McSPI0->CH0STAT -->> 	  = 0x%x\r\n",McSPI0->CH0STAT);   
	 }
	
	//通道0禁止
 	McSPI0->CH0CTRL = 0x0; 
	 
 }



void McSPIIsr(void)
	{


	}


void spi2_gpio_init(void)
{

	CM_PER_L4LS_CLKSTCTRL &= ~(0x3 <<0);
	CM_PER_L4LS_CLKSTCTRL |= (0x01<<25 | 0x1 << 21);	
	printf("CM_PER_L4LS_CLKSTCTRL -->> 	 = 0x%x\r\n",CM_PER_L4LS_CLKSTCTRL);


	CM_PER_SPI0_CLKCTRL |= (0x2 << 0);
	printf("CM_PER_SPI0_CLKCTRL -->>		 = 0x%x\r\n",CM_PER_SPI0_CLKCTRL);
	


	
	CM_PER_GPIO3_CLKCTRL  |= (0x02<<0);

	CONF_MCASP0_FSX    |= (0x3 <<0); 
	CONF_MCASP0_ACLKX	 |= (0x3 <<0);
	CONF_MCASP0_AHCLKR	|= (0x3 <<0);



	//操作oled 不使用接收功能引脚，设置为普通gpio用作oled DC引脚 gpio3_16
	CONF_MCASP0_AXR0 |= (0x7 <<0 );

	GPIO3_OE	   &= ~(0x01<<16);//输出
	GPIO3_DATAOUT |=  (0x01<<16);//拉高

	

}

 void spi_init(void)
  {
	
		 
	 /*spi2中断初始化*/  
	 spi2_gpio_init();		  
	 IntSystemEnable(McSPI0INT);
	 register_irq(McSPI0INT, McSPIIsr); 	  
	 interrupt_init(McSPI0INT,0,0);
	  

 
	   
	   /*McSPIReset 		   
	   *McSPICSEnable		   
	   *McSPIMasterModeEnable  
	   *McSPIMasterModeConfig  
	   *					   
	   *McSPIClkConfig		   
	   *McSPIWordLengthSet	   
	   *McSPICSPolarityConfig  
	   *McSPITxFIFOConfig	   
	   *McSPIRxFIFOConfig	   
	   */
	   
	 //软件复位操作
	 McSPI0->SYSCONFIG	|= (0x1 << 1 ); 
	   
	 printf("McSPI0->SYSCONFIG	  = 0x%x\r\n",McSPI0->SYSCONFIG   );   
	 while(!(McSPI0->SYSSTS & (0x01<<0)));//1h (R) = Reset completed 
	   
	 //值为1表示复位完成
	 printf("McSPI0->SYSSTS-->> 	= 0x%x\r\n",McSPI0->SYSSTS );
	   
	 /*模块配置
	 *（a）写入MCSPI_MODULCTRL
	 *（b）写入MCSPI_SYSCONFIG。
	 */
		   
	 McSPI0->MODULCTRL &= ~(0x1 << 1); //bit 1 4PIN mode
	 McSPI0->MODULCTRL &= ~(0x1 << 2); //master mode
	 printf("McSPI0->MODULCTRL-->>		= 0x%x\r\n",McSPI0->MODULCTRL );
	   
			  
	 //默认为发送和接受模式，所以下面不做设置
	 // McSPI0->CH0CONF &= ~( 0x3 << 12);	 // Transmit and Receive mode
 
	 //默认是 DAT1 作为输入 DAT0作为输出
	 McSPI0->CH0CONF &= ~( 0x1 << 16); //D0 output	D1 intput
	 McSPI0->CH0CONF |= ( 0x2 << 12);	 // Transmit only mode
 
 
	 //配置分频系数
	 McSPI0->CH0CONF  &= ~(0x1 << 29 ); //
	 McSPI0->CH0CONF  |= (0x1 << 2 ); //2 rate 24Mhz
 
 
	 //配置时钟模式
 
	 /* OLED  is  mode 4  */
 
	 McSPI0->CH0CONF  |= (0x1 << 1 ); //pclk mode
	 McSPI0->CH0CONF  |= (0x1 << 0);
							 
 
 
	 McSPI0->CH0CONF  |= (0x7 << 7 ); //McSPIWordLengthSet	8bit   
	 McSPI0->CH0CONF  |= (0x1 << 6 ); //1h (R/W) = SPIEN is held low during the active state.
 
	 //McSPI0->CH0CONF	|= (0x1 << 23 ); //Start bit enable for SPI transfe
					   
	 printf("McSPI0->CH0CONF-->>	= 0x%x\r\n",McSPI0->CH0CONF );
 
   
 }

 #if 0
 void spi_init(void)
 {




		spi2_gpio_init();	
		
		IntSystemEnable(McSPI0INT);
		register_irq(McSPI0INT, McSPIIsr);		 
		interrupt_init(McSPI0INT,0,0);
		 
		 /*McSPIReset			 
		 *McSPICSEnable 		 
		 *McSPIMasterModeEnable  
		 *McSPIMasterModeConfig  
		 *						 
		 *McSPIClkConfig		 
		 *McSPIWordLengthSet	 
		 *McSPICSPolarityConfig  
		 *McSPITxFIFOConfig 	 
		 *McSPIRxFIFOConfig 	 
		 */
	 
		//reset
		 McSPI0->SYSCONFIG	|= (0x1 << 1 ); 
	 
		 printf("McSPI0->SYSCONFIG	  = 0x%x\r\n",McSPI0->SYSCONFIG   );
	 
		 while(!(McSPI0->SYSSTS & (0x01<<0)));//1h (R) = Reset completed 
	 
		 //值为1表示复位完成
		 printf("McSPI0->SYSSTS-->> 	  = 0x%x\r\n",McSPI0->SYSSTS );
	 
		 /*2 模块配置
		 *（a）写入MCSPI_MODULCTRL
		 *（b）写入MCSPI_SYSCONFIG。
		 */
	 
		 
		 /*McSPICSEnable		 
		 *McSPIMasterModeEnable  
		 *McSPIMasterModeConfig 	 
		 */
		 
		 McSPI0->MODULCTRL &= ~(0x1 << 1); //bit 1 4PIN mode
		 McSPI0->MODULCTRL &= ~(0x1 << 2); //master mode
	 
		 McSPI0->MODULCTRL |= (0x1 << 0); // Only one channel 
		 printf("McSPI0->MODULCTRL-->> 	  = 0x%x\r\n",McSPI0->MODULCTRL );
	 
		 McSPI0->CH0CONF &= ~( 0x3 << 16); //D0 output	D1 intput
		 McSPI0->CH0CONF |= ( 0x2 << 12);  //仅发送模式
	 
		 //配置分频系数
		 McSPI0->CH0CONF  &= ~(0x1 << 29 ); //
		 McSPI0->CH0CONF  |= (0x5 << 2 ); //16 rate
	 
		 //配置时钟模式
		 McSPI0->CH0CONF  &= ~(0x1 << 1 | 0x1 << 0); //pclk mode 0
		 printf("McSPI0->CH0CONF-->>	  = 0x%x\r\n",McSPI0->CH0CONF );
		 /*
		 *McSPIWordLengthSet	 
		 *McSPICSPolarityConfig  
		 *McSPITxFIFOConfig 	 
		 *McSPIRxFIFOConfig  
		 */
		 McSPI0->CH0CONF  |= (0x7 << 7 ); //McSPIWordLengthSet	8bit
	 
		 McSPI0->CH0CONF  |= (0x1 << 6 ); //1h (R/W) = SPIEN is held low during the active state.
	 
		 McSPI0->CH0CONF  |= (0x1 << 27 ); //McSPITxFIFOConfig	 enable
		 printf("McSPI0->CH0CONF-->>	  = 0x%x\r\n",McSPI0->CH0CONF );



 
 
 }



 unsigned char spi_recv_byte(void)
 
 {
	 unsigned char data;
 
 //  printf("spi send data: 0x%x, STATUS before send 0xff: 0x%x\n\r", data, McSPI2->CH0STAT);
 
	 //接受寄存器为满的时候发送 直到为空则 返回 val值
	 McSPI0->TX0 = 0xff;
	 
	  while (!(McSPI0->CH0STAT & (1 << 1)))
	 {
		  printf("wait for recv .... McSPI2->CH0STAT -->>	   = 0x%x\r\n",McSPI0->CH0STAT);   
	  }
	  
	 data  = McSPI0->RX0;
					 
	 
	 return data;
 
 }
#endif
