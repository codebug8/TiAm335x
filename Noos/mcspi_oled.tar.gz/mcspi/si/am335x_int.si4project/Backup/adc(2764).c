#include "AM335X_SOC.h"
#include "delay.h"
#include "printf.h"
#include "adc.h"

void debug_adc(char *str);


void adc0_init(void)
{


	//System Clock for ADC0.CP552
	PRCM_CM_WKUP_ADC0_CLKCTRL  |=  (0X02<<0);//CP561
	PRCM_CM_L3S_ADC0_CLKSTCTRL &= ~(0X02<<0);//CP559


	//SP21,GPIO没有复用；
	//CTRL_CONF_GPMC_AD0 &= ~(0x01<<0);//不是这个脚;CP694
	
	//ADC0 Capture Control.CP635;CP1047
	CTRL_ADC0_EVT_CAPT |= (0X01<<0);//Timer 4 Event.CP1047 ???暂时还没确定
	
	//ADC0 sysconfig.CP1800
	ADC->SYSCONFIG |= (0X01<<2);//No Idle Mode (never acknowledges)

	//Disable module.CP1812
	ADC->CTRL &= ~(0x01<<0);
	
	//sets the AFE clock. CP1816
	ADC->ADC_CLKDIV |= (0x05<<0);

	//Disable Write Protection. CP1812
	ADC->CTRL |= (0x01<<2);
	
	//Configure step 1 for channel 1(AN0). CP1824
	ADC0->STEPCONFIG_0 &= ~(0x01<<26);//默认数据在FIFO0；ADC0_FIFO0DATA


	//设置参考源；低电压参考源bit24-23;高电压参考源bit14-12
	ADC->STEPCONFIG_0 &= ~(0x03<<23 | 0x07<<12);
	ADC->STEPCONFIG_0 &= ~(0x0f<<19);//bit22-19 写为0 --通道1；
	ADC->STEPCONFIG_0 |=  (0x08<<15);//bit18-15 写为8 --vrefn；
	//ADC0->STEPCONFIG_0 |=  (0x01<<5);//可能是差分相关；
	ADC->STEPCONFIG_0 |=  (0x04<<2);//N次采样后，取平均值；现在设置的是16次采样；
	ADC->STEPCONFIG_0 &= ~(0x01<<0);//软件使能，单次转换；
	
	//选择哪些通道需要采样；Enable step 1 .CP1818
	ADC->STEPEN |= (0x01<<1);
	
	//Enable interrput.CP1805
	ADC->IRQEN_SET |= (0x01<<1);//必须设置IRQEN_SET，才能读取IRQSTS中已经使能的位；
	
	//Enable module.CP1812
	ADC->CTRL |= (0x01<<0);

	//debug_adc("11");

}	
	



/*********************************************************************************
   *Function:	  loop_judge_register_bits
   *Description： 循环判断某个寄存器的值为多少
   *Input:		  寄存器地址，哪些bit位，期待值
   *Output: 	  \
   *Return: 	  0
   *Others: 	  \
**********************************************************************************/
int  loop_judge_register_bits(unsigned	int reg_addr, unsigned	int bits, unsigned	int expected_val)
{
	volatile unsigned  int	reg=reg_addr;	
	unsigned  int  tmp=0;//volatile unsigned  int  tmp=0;
	
	do
	{
		tmp = reg;
		tmp = tmp & (bits); 
	}
	while(expected_val !=  tmp);//判断

	return 0;
}



/*********************************************************************************
   *Function:	  debug_adc
   *Description： 调试程序打印出全部相关寄存器
   *Input:		  字符串标记
   *Output: 	  \
   *Return: 	  0
   *Others: 	  将传入参数由整型改为字符型
**********************************************************************************/
void debug_adc(char *str)
{
	printf("-------------------------%s---------------------------\r\n",str);
	//printf("REVISION		 = 0x%x\r\n",ADC0->REVISION 		 ); 	
	printf("SYSCONFIG		 = 0x%x\r\n",ADC0->SYSCONFIG		 ); 	
	printf("IRQSTS_RAW		 = 0x%x\r\n",ADC0->IRQSTS_RAW		 );  
	printf("IRQSTS			 = 0x%x\r\n",ADC0->IRQSTS			 );  
	printf("IRQEN_SET		 = 0x%x\r\n",ADC0->IRQEN_SET		 ); 	
	printf("IRQEN_CLR		 = 0x%x\r\n",ADC0->IRQEN_CLR		 );  
	//printf("IRQWAKEUP 	 = 0x%x\r\n",ADC0->IRQWAKEUP		 );  
	//printf("DMAEN_SET 	 = 0x%x\r\n",ADC0->DMAEN_SET		 );  
	//printf("DMAEN_CLR 	 = 0x%x\r\n",ADC0->DMAEN_CLR		 );  
	printf("CTRL			 = 0x%x\r\n",ADC0->CTRL 			 );  
	printf("ADCSTAT 		 = 0x%x\r\n",ADC0->ADCSTAT			 );  
	printf("ADCRANGE		 = 0x%x\r\n",ADC0->ADCRANGE 		 );  
	//printf("ADC_CLKDIV		 = 0x%x\r\n",ADC0->ADC_CLKDIV		 );  
	//printf("ADC_MISC		 = 0x%x\r\n",ADC0->ADC_MISC 		 );  
	printf("STEPEN			 = 0x%x\r\n",ADC0->STEPEN			 );  
	printf("IDLECONFIG		 = 0x%x\r\n",ADC0->IDLECONFIG		 );  
	printf("TS_CHARGE_STEPCONFIG= 0x%x\r\n",ADC0->TS_CHARGE_STEPCONFIG );  
	printf("TS_CHARGE_DELAY  = 0x%x\r\n",ADC0->TS_CHARGE_DELAY	 );  
	printf("STEPCONFIG_0	 = 0x%x\r\n",ADC0->STEPCONFIG_0 	 );  
	printf("STEPDELAY_0 	 = 0x%x\r\n",ADC0->STEPDELAY_0		 );  
	printf("STEPCONFIG_1	 = 0x%x\r\n",ADC0->STEPCONFIG_1 	 );  
	printf("STEPDELAY_1 	 = 0x%x\r\n",ADC0->STEPDELAY_1		 ); 
	
	//printf("STEPCONFIG_2	 = 0x%x\r\n",ADC0->STEPCONFIG_2 	 );  
	//printf("STEPDELAY_2	 = 0x%x\r\n",ADC0->STEPDELAY_2		 );  
	//printf("STEPCONFIG_3	 = 0x%x\r\n",ADC0->STEPCONFIG_3 	 );  
	//printf("STEPDELAY_3	 = 0x%x\r\n",ADC0->STEPDELAY_3		 );  
	//printf("STEPCONFIG_4	 = 0x%x\r\n",ADC0->STEPCONFIG_4 	 );  
	//printf("STEPDELAY_4	 = 0x%x\r\n",ADC0->STEPDELAY_4		 );  
	//printf("STEPCONFIG_5	 = 0x%x\r\n",ADC0->STEPCONFIG_5 	 );  
	//printf("STEPDELAY_5	 = 0x%x\r\n",ADC0->STEPDELAY_5		 );  
	//printf("STEPCONFIG_6	 = 0x%x\r\n",ADC0->STEPCONFIG_6 	 );  
	//printf("STEPDELAY_6	 = 0x%x\r\n",ADC0->STEPDELAY_6		 );  
	//printf("STEPCONFIG_7	 = 0x%x\r\n",ADC0->STEPCONFIG_7 	 );  
	//printf("STEPDELAY_7	 = 0x%x\r\n",ADC0->STEPDELAY_7		 );  
	//printf("STEPCONFIG_8	 = 0x%x\r\n",ADC0->STEPCONFIG_8 	 );  
	//printf("STEPDELAY_8	 = 0x%x\r\n",ADC0->STEPDELAY_8		 );  
	//printf("STEPCONFIG_9	 = 0x%x\r\n",ADC0->STEPCONFIG_9 	 );  
	//printf("STEPDELAY_9	 = 0x%x\r\n",ADC0->STEPDELAY_9		 );  
	//printf("STEPCONFIG_10  = 0x%x\r\n",ADC0->STEPCONFIG_10	 );  
	//printf("STEPDELAY_10	 = 0x%x\r\n",ADC0->STEPDELAY_10 	 );  
	//printf("STEPCONFIG_11  = 0x%x\r\n",ADC0->STEPCONFIG_11	 );  
	//printf("STEPDELAY_11	 = 0x%x\r\n",ADC0->STEPDELAY_11 	 );  
	//printf("STEPCONFIG_12  = 0x%x\r\n",ADC0->STEPCONFIG_12	 );  
	//printf("STEPDELAY_12	 = 0x%x\r\n",ADC0->STEPDELAY_12 	 );  
	//printf("STEPCONFIG_13  = 0x%x\r\n",ADC0->STEPCONFIG_13	 );  
	//printf("STEPDELAY_13	 = 0x%x\r\n",ADC0->STEPDELAY_13 	 );  
	//printf("STEPCONFIG_14  = 0x%x\r\n",ADC0->STEPCONFIG_14	 );  
	//printf("STEPDELAY_14	 = 0x%x\r\n",ADC0->STEPDELAY_14 	 );  
	//printf("STEPCONFIG_15  = 0x%x\r\n",ADC0->STEPCONFIG_15	 );  
	//printf("STEPDELAY_15	 = 0x%x\r\n",ADC0->STEPDELAY_15 	 );  
	printf("FIFOCOUNT_0 	 = 0x%x\r\n",ADC0->FIFOCOUNT_0		 );  
	printf("FIFOTHR_0		 = 0x%x\r\n",ADC0->FIFOTHR_0		 );  
	printf("DMAREQ_0		 = 0x%x\r\n",ADC0->DMAREQ_0 		 );  
	printf("FIFOCOUNT_1 	 = 0x%x\r\n",ADC0->FIFOCOUNT_1		 );  
	printf("FIFOTHR_1		 = 0x%x\r\n",ADC0->FIFOTHR_1		 );  
	printf("DMAREQ_1		 = 0x%x\r\n",ADC0->DMAREQ_1 		 );    
	printf("FIFO0DATA		 = 0x%x\r\n",ADC0->FIFO0DATA		 );  
	printf("FIFO1DATA		 = 0x%x\r\n",ADC0->FIFO1DATA		 );  
	printf("******************************************************\r\n");


}


