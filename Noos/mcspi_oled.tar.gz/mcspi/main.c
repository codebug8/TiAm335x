﻿#include "AM335X_SOC.h"
#include "uart.h"
#include "spi.h"
#include "oled.h"
#include "printf.h"
//#include "spi_flash.h"


void mdelay(int times);
int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val);



void mdelay(int times)
{
	volatile int i, j;
	for(j = 0 ; j < times; j++ )
		{	for(i=0; i < 100000; i++ );
			i = i+1;
		}
}

int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val)
{
	volatile unsigned  int  reg=reg_addr;	
	unsigned  int  tmp=0;//volatile unsigned  int  tmp=0;
	
	do
	{
		tmp = reg;
		tmp = tmp & (bits); 
	}
	while(expected_val !=  tmp);//判断

	return 0;
}

	





int main()
{

    unsigned int mid, pid;    
    
    uart_init();   // 波特率115200，8N1(8个数据位，无校验位，1个停止位)
		
	gic_init();
	spi_init();

	//SPIFlashReadID(&mid, &pid);
   // printf("SPI Flash : MID = 0x%02x, PID = 0x%02x\n\r", mid, pid);
    OLEDInit();
    OLEDPrint(0,0,"www.100ask.net");
    
    
    while (1)
    {
        
      // printf("Enter your selection: \r\n");

      
    	}
    return 0;
}
