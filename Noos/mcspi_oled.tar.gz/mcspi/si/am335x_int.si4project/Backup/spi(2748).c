#include "AM437X/AM437X_SOC.h"
#include "spi.h"
#include "uart.h"
#include "printf.h"
#include "int.h" 
#include "delay.h" 


uint32_t		  length = 0;
unsigned char	 txBuffer[McSPI_DATA_COUNT + 10];

/*********************************************************************************
   *Function:     delay
   *Description： 简单延时
   *Input:        循环次数
   *Output:       \
   *Return:       0
   *Others:       1500000约等于1s;
**********************************************************************************/
void  delay(unsigned int   i)
{
	volatile unsigned int count = i;
	volatile unsigned int temp = 5;
	
	for(; count > 0; count--)
		for(;temp>0;temp--);
}

#if 0
static void spi_gpio_init(void)
{
   

	PRCM_CM_PER_GPIO3_CLKCTRL  |= (0x02<<0);

	CTRL_CONF_SPI2_CS0 |= (0x7 << 0 | 0x1 << 19); //gpio3_25  cs
	CTRL_CONF_SPI2_D0  |= (0x7 << 0 | 0x1 << 19 ); //gpio3_22 d0
	//CTRL_CONF_SPI2_D1 
	CTRL_CONF_SPI2_SCLK |= (0x7 << 0  | 0x1 << 19); //gpio3_24  clk



	
	//操作oled 不使用接收功能引脚，设置为普通gpio用作oled DC引脚 gpio3_16
	CTRL_CONF_MCASP0_AXR0 |= (0x7 <<0 | 0x01<<19);
	CTRL_CONF_MCASP0_AXR0 &= ~( 0x01<<16 );

	GPIO3->OE	   &= ~(0x01<<16 | 0x1 << 22 | 0x1 << 24 | 0x1 <<25 );//输出
	GPIO3->DATAOUT |=  (0x01<<16 | 0x1 << 22 | 0x1 << 24 | 0x1 <<25);//拉高
	




}

static void spi_set_clk(char val)
{
    if(val) {
        GPIO3->DATAOUT |=  (0x1 << 24);
    } 
    else {
        GPIO3->DATAOUT &= ~(0x1 << 24);
    }   
}

static void spi_set_d0(char val)
{
    if(val) {
        GPIO3->DATAOUT |=  (0x01<<22);
    } 
    else {
        GPIO3->DATAOUT &= ~(0x01<<22);
    } 
    
}

static void spi_set_cs(char val)
{
    if(val) {
        GPIO3->DATAOUT |=  (0x01<<25);
    } 
    else {
        GPIO3->DATAOUT &= ~(0x01<<25);
    }  
}


void spi_send_byte(unsigned char val)
{
    int i;
    for (i = 0; i < 8; i++)
    {
        spi_set_clk(0);
        spi_set_d0(val & 0x80);
        spi_set_clk(1); 
        val <<= 1;
    }
    
}



void spi_init(void)
{
    /* 初始化引脚 */
    spi_gpio_init();
}


#endif


#if 1

 
void spi_send_byte(unsigned char val)
{			

	
	//通道使能
	McSPI2->CH0CTRL |= (0x1 << 0);
	printf("McSPI2->CH0CTRL +++-->> 	 = 0x%x\r\n",McSPI2->CH0CTRL); 

	//设置为片选状态  0 也就是选中状态 
	McSPI2->CH0CONF  &=  ~(0x1 << 20 );

	printf("McSPI2->CH0CONF send-->>		 = 0x%x\r\n",McSPI2->CH0CONF); 
	//中断状态清理	  
	McSPI2->SYST |= ( 0x1 << 11);	
	McSPI2->IRQSTS |= ( 0x1 << 0);	
	
   //中断使能
   /* Enable the Interrupts. */
  
  	//McSPI2->IRQEN |= ( 0x1 << 3 | 0x1 << 2 | 0x1 << 1 | 0x1 << 0);	
   ///printf("McSPI2->IRQEN send-->>		 = 0x%x\r\n",McSPI2->IRQEN); 

   printf("spi send data: \n\r");
  	
	
	//val = McSPI2->TX0;
	
	McSPI2->TX0 = 0x55;
	printf("McSPI2->TX0 +++-->> 	 = 0x%x\r\n",McSPI2->TX0); 

	printf("McSPI2->CH0STAT -->>		 = 0x%x\r\n",McSPI2->CH0STAT);   
					
			
	//关闭TX0_EMPTY中断
	McSPI2->IRQEN &= ( 0x1 << 0);	
	
	//中断状态清理	  
	McSPI2->SYST |= ( 0x1 << 11);	
	McSPI2->IRQSTS |= ( 0x1 << 0);

	 //设置为片选状态  为1 
	  
	McSPI2->CH0CONF  |=  (0x1 << 20 );


	//通道1禁止
	McSPI2->CH0CTRL = 0x0;


				

	
}






#if 1

		 void McSPIIsr(void)
		{
#if 0		
			unsigned int intCode = 0;
			unsigned char *p_tx = txBuffer ;
			unsigned char val;
		
			unsigned char	 txBuffer[McSPI_DATA_COUNT + 10];
		
			intCode = McSPI2->IRQSTS;
		
			while(intCode)
			{
				//如果发送为空
				if((0x1 << 0)	== (intCode & (0x1 << 0)))
				{		 
					//中断状态清理	  
					McSPI2->SYST |= ( 0x1 << 11);	
					McSPI2->IRQSTS |= ( 0x1 << 0);	
					
				  
					//spi_send_byte(val);
							
					
					printf("McSPI2->TX0 ++irq+-->>		 = 0x%x\r\n",McSPI2->TX0);	 
		
					if(!length)
					{		
		
						//关闭TX0_EMPTY中断
						McSPI2->IRQEN &= ( 0x1 << 0);	
						
						//中断状态清理	  
						McSPI2->SYST |= ( 0x1 << 11);	
						McSPI2->IRQSTS |= ( 0x1 << 0);	
						
					printf("McSPI2->IRQSTS +irq++-->>		 = 0x%x\r\n",McSPI2->IRQSTS); 
					}
				}


        if(MCSPI_INT_RX_FULL(chNum) == (intCode & MCSPI_INT_RX_FULL(chNum)))
        {
            McSPIIntStatusClear(SOC_SPI_0_REGS, MCSPI_INT_RX_FULL(chNum));

            *p_rx++ = (unsigned char) McSPIReceiveData(SOC_SPI_0_REGS, chNum);

            if(!(length))
            {
                McSPIIntDisable(SOC_SPI_0_REGS, MCSPI_INT_RX_FULL(chNum));

                flag = 0;
            }
        }



        intCode = McSPI2->IRQSTS;
    }
#endif

}

#endif


 static void spi1_gpio_init(void)
 {



	PRCM_CM_PER_SPI1_CLKCTRL  |= (0x2 <<0);
	PRCM_CM_PER_SPI1_CLKCTRL &= ~(0x3 << 16);
	printf("PRCM_CM_PER_SPI1_CLKCTRL-->>		 = 0x%x\r\n",PRCM_CM_PER_SPI1_CLKCTRL);

	
	 PRCM_CM_PER_L4LS_CLKSTCTRL |= (0x01<<9);

	 
	 printf("PRCM_CM_PER_L4LS_CLKSTCTRL-->> 	  = 0x%x\r\n",PRCM_CM_PER_L4LS_CLKSTCTRL);
 

	 
	 PRCM_CM_PER_GPIO3_CLKCTRL	|= (0x02<<0);
 
	 //SPI1_CLK
	 CTRL_CONF_MCASP0_AHCLKX |= (0x3 <<0 );  
	
	 
	 //SPI1_D0
	 CTRL_CONF_MCASP0_FSX |= (0x3 <<0 ); 
	
  
 
	 //SPI1_CS0
	 CTRL_CONF_MCASP0_AHCLKR |= (0x3 <<0 );
	
 
	 
	 //操作oled 不使用接收功能引脚，设置为普通gpio用作oled DC引脚 gpio3_16
	 CTRL_CONF_MCASP0_AXR0 |= (0x7 <<0 | 0x01<<19);
	 CTRL_CONF_MCASP0_AXR0 &= ~( 0x01<<16 );
	 
	 GPIO3->OE		&= ~(0x01<<16);//输出
	 GPIO3->DATAOUT |=	(0x01<<16);//拉高
	 
 }

#if 1
 void spi2_gpio_init(void)
{

	PRCM_CM_PER_SPI2_CLKCTRL |= (0x2 << 0);
	PRCM_CM_PER_SPI2_CLKCTRL &= ~(0x3 << 16);
	printf("PRCM_CM_PER_SPI2_CLKCTRL -->>		 = 0x%x\r\n",PRCM_CM_PER_SPI2_CLKCTRL);
	
	PRCM_CM_PER_L4LS_CLKSTCTRL |= (0x01<<9);
//	PRCM_CM_PER_L4LS_CLKSTCTRL &= ~(0x01<<8);
	
	printf("PRCM_CM_PER_L4LS_CLKSTCTRL -->>		 = 0x%x\r\n",PRCM_CM_PER_L4LS_CLKSTCTRL);

	
	PRCM_CM_PER_GPIO3_CLKCTRL  |= (0x02<<0);

	CTRL_CONF_SPI2_CS0 &= ~(0x7 << 0);
	CTRL_CONF_SPI2_D0  &= ~(0x7 << 0);
	//CTRL_CONF_SPI2_D1
	CTRL_CONF_SPI2_SCLK &= ~(0x7 << 0);


	//操作oled 不使用接收功能引脚，设置为普通gpio用作oled DC引脚 gpio3_16
	CTRL_CONF_MCASP0_AXR0 |= (0x7 <<0 | 0x01<<19);
	CTRL_CONF_MCASP0_AXR0 &= ~( 0x01<<16 );

	GPIO3->OE	   &= ~(0x01<<16);//输出
	GPIO3->DATAOUT |=  (0x01<<16);//拉高

	

}

 #endif 
 
 
 void spi_init(void)
 {
	 spi2_gpio_init();
	 
	
	register_irq(SPI2INT, McSPIIsr);
		 
	interrupt_init(SPI2INT);
	 
	 /*McSPIReset			 
	 *McSPICSEnable 		 
	 *McSPIMasterModeEnable  
	 *McSPIMasterModeConfig  
	 *						 
	 *McSPIClkConfig		 
	 *McSPIWordLengthSet	 
	 *McSPICSPolarityConfig  
	 *McSPITxFIFOConfig 	 
	 *McSPIRxFIFOConfig 	 
	 */
	 
	 	//reset
		 McSPI2->SYSCONFIG	|= (0x1 << 1 ); 
	 
		 printf("McSPI2->SYSCONFIG	  = 0x%x\r\n",McSPI2->SYSCONFIG   );
	 
		 while(!(McSPI2->SYSSTS & (0x01<<0)));//1h (R) = Reset completed 
	 
		 //值为1表示复位完成
		 printf("McSPI2->SYSSTS-->> 	  = 0x%x\r\n",McSPI2->SYSSTS );
	 
		 /*2 模块配置
		 *（a）写入MCSPI_MODULCTRL
		 *（b）写入MCSPI_SYSCONFIG。
		 */
	 
		 
		 /*McSPICSEnable		 
		 *McSPIMasterModeEnable  
		 *McSPIMasterModeConfig 	 
		 */
		 
		 McSPI2->MODULCTRL &= ~(0x1 << 1); //bit 1 4PIN mode
		 McSPI2->MODULCTRL &= ~(0x1 << 2); //master mode
	 
		 McSPI2->MODULCTRL |= (0x1 << 0); // Only one channel 
		  printf("McSPI2->MODULCTRL-->> 	  = 0x%x\r\n",McSPI2->MODULCTRL );
	 
		 McSPI2->CH0CONF &= ~( 0x3 << 16); //D0 output	D1 intput
		 McSPI2->CH0CONF |= ( 0x2 << 12);  //仅发送模式
	 
		 //配置分频系数
		 McSPI2->CH0CONF  &= ~(0x1 << 29 ); //
		 McSPI2->CH0CONF  |= (0x5 << 2 ); //16 rate
	 
		 //配置时钟模式
		 McSPI2->CH0CONF  &= ~(0x1 << 1 | 0x1 << 0); //pclk mode 0
		   printf("McSPI2->CH0CONF-->> 	  = 0x%x\r\n",McSPI2->CH0CONF );
		 /*
		 *McSPIWordLengthSet	 
		 *McSPICSPolarityConfig  
		 *McSPITxFIFOConfig 	 
		 *McSPIRxFIFOConfig  
		 */
		 McSPI2->CH0CONF  |= (0x7 << 7 ); //McSPIWordLengthSet	8bit
	 
		 McSPI2->CH0CONF  |= (0x1 << 6 ); //1h (R/W) = SPIEN is held low during the active state.
	 
		 McSPI2->CH0CONF  |= (0x1 << 27 ); //McSPITxFIFOConfig	 enable
		  printf("McSPI2->CH0CONF-->> 	  = 0x%x\r\n",McSPI2->CH0CONF );



 
 
 }



#if 0

static void spi1_gpio_init(void)
{

	PRCM_CM_PER_L4LS_CLKSTCTRL |= (0x01<<9);
	PRCM_CM_PER_L4LS_CLKSTCTRL &= ~(0x01<< 0 );
	
	printf("PRCM_CM_PER_L4LS_CLKSTCTRL-->>		 = 0x%x\r\n",PRCM_CM_PER_L4LS_CLKSTCTRL);

	PRCM_CM_PER_SPI1_CLKCTRL  |= (0x2 <<0);
	
	printf("PRCM_CM_PER_SPI1_CLKCTRL-->>		 = 0x%x\r\n",PRCM_CM_PER_SPI1_CLKCTRL);
	
	PRCM_CM_PER_GPIO3_CLKCTRL  |= (0x02<<0);

	//SPI1_CLK
	CTRL_CONF_MCASP0_AHCLKX |= (0x3 <<0 );	
	CTRL_CONF_MCASP0_AHCLKX  &= ~(0x1 << 18 | 0x01<<16 );
	
	//SPI1_D0
	CTRL_CONF_MCASP0_FSX |= (0x3 <<0 );	
	CTRL_CONF_MCASP0_FSX &= ~(0x1 << 18 | 0x01<<16 );
 

	//SPI1_CS0
	CTRL_CONF_MCASP0_AHCLKR |= (0x3 <<0 );
	CTRL_CONF_MCASP0_AHCLKR  &= ~(0x1 << 18 | 0x01<<16 );

	
	//操作oled 不使用接收功能引脚，设置为普通gpio用作oled DC引脚 gpio3_16
	CTRL_CONF_MCASP0_AXR0 |= (0x7 <<0 | 0x01<<19);
	CTRL_CONF_MCASP0_AXR0 &= ~( 0x01<<16 );
	
	GPIO3->OE      &= ~(0x01<<16);//输出
	GPIO3->DATAOUT |=  (0x01<<16);//拉高
	
}




//强制进入空闲模式
//McSPI2->HL_SYSCONFIG &= ~(0x3 << 2 );
//printf("McSPI2->HL_SYSCONFIG-->>		 = 0x%x\r\n",McSPI2->HL_SYSCONFIG );


void spi_transfer( unsigned char data)
{

	
	//1h (R/W) = Start bit D/CX added before SPI transfer polarity is defined by MCSPI_CH0CONF[SBPOL]
	//bit 6 1h (R/W) = SPIEN is held low during the active state.
	McSPI1->CH0CONF |= (0x1 << 23  | 0x1 << 6); 

	
	//使能所有的中断复位
	//起始位为高电平
	//D1 设置为输入
	//D0 设置为输出
	McSPI1->SYST |= (0x1 << 11 |  0x1 << 9  | 0x1 << 4 )

	//Set the direction of the SPIEN
	McSPI1->SYST  &= ~(0x1 << 10 | 0x1 << 8 | 0x1 << 0); 	

	//bit 0 1h (R/W) = Channel "i" is active
	McSPI1->CH0CTRL |=  (0x1 << 0);

	u8 data;
	data = McSPI1->TX0;

}


unsigned char spi_recv_byte(void)
{
    char recv;

    McSPI1->CH0CONF |=  (0x01<<23);//Start bit enable for SPI transfer

    while((McSPI1->CH0CONF & (0x01<<0)));
    recv = McSPI1->RX0;
    //while(!r_ok);
    //r_ok = 0;   

    return recv;    
}



#endif

#endif


