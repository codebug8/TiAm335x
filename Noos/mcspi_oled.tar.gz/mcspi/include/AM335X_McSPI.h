#ifndef   _AM335X_MCSPI_H_
#define   _AM335X_MCSPI_H_

#include  "AM335X_DataType.h"
#include  "AM335X_Mapping.h"

typedef struct {
	uint32_t   REVISION;			  //0h
	uint32_t   RESERVED1[67];	   //04
	uint32_t   SYSCONFIG;	 	 //110h
	uint32_t   SYSSTS;    		//114h
	uint32_t   IRQSTS;   		 //118h
	uint32_t   IRQEN;   			//11Ch
	uint32_t   RESERVED2[1];       //120h	
	uint32_t   SYST;         //124h
	uint32_t   MODULCTRL;    //128h
	uint32_t   CH0CONF;      //12Ch
	uint32_t   CH0STAT;      //130h
	uint32_t   CH0CTRL;      //134h
	uint32_t   TX0;          //138h
	uint32_t   RX0;          //13Ch
	uint32_t   CH1CONF;      //140h
	uint32_t   CH1STAT;      //144h
	uint32_t   CH1CTRL;      //148h
	uint32_t   TX1;          //14Ch
	uint32_t   RX1;          //150h
	uint32_t   CH2CONF;      //154h
	uint32_t   CH2STAT;      //158h
	uint32_t   CH2CTRL;      //15Ch
	uint32_t   TX2;          //160h
	uint32_t   RX2;          //164h
	uint32_t   CH3CONF;      //168h
	uint32_t   CH3STAT;      //16Ch
	uint32_t   CH3CTRL;      //170h
	uint32_t   TX3;          //174h
	uint32_t   RX3;          //178h
	uint32_t   XFERLEVEL;    //17Ch
	uint32_t   DAFTX;        //180h
	uint32_t   RESERVED3[7];       //184h
	uint32_t   DAFRX;        //1A0h

}McSPI_Typedef;

#define   McSPI0   		((volatile McSPI_Typedef *)McSPI0_BASE)  
#define   McSPI1   		((volatile McSPI_Typedef *)McSPI1_BASE)
#endif
