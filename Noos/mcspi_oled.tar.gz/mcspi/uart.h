
#ifndef   __UART_H__
#define   __UART_H__

extern void  uart_init();
extern void  uart_PutChar(char  c);

extern void  uart_PutString(char *ptr);

#endif

