#include "AM335X_SOC.h"
#include "printf.h"
#include "interrupt.h"


static irq_func g_irq_func_array[128];

/**************** *************************************************************
**                 STATIC VARIABLE DEFINITIONS
******************************************************************************/
void (*fnRAMVectors[128])(void);



/*
**
** Wrapper function for the IRQ enable function
**
*/
void CPUirqe(void)
{
	/* Enable IRQ in CPSR */
	asm("	 mrs	 r0, CPSR\n\t"
		"	 bic	 r0, r0, #0x80\n\t"
		"	 msr	 CPSR_c, r0");
}

/*
**
** Wrapper function for the IRQ disable function
**
*/
void CPUirqd(void)
{
	/* Disable IRQ in CPSR */
	asm("	 mrs	 r0, CPSR\n\t"
		"	 orr	 r0, r0, #0x80\n\t"
		"	 msr	 CPSR_c, r0");
}







/**
 * The Default Interrupt Handler.
 *
 * This is the default interrupt handler for all interrupts. It simply returns
 * without performing any operation.
 **/
static void IntDefaultHandler(void)
{
    /* Go Back. Nothing to be done */
    ;
}

void gic_init(void)
{
    unsigned int irq;

    /* Reset the ARM interrupt controller */
    INTC_SYSCONFIG = INTC_SYSCONFIG_SOFTRESET;
 
    /* Wait for the reset to complete */
    while ((INTC_SYSSTATUS  & INTC_SYSSTATUS_RESETDONE) != INTC_SYSSTATUS_RESETDONE);    
  
    /* Enable any interrupt generation by setting priority threshold */ 
   INTC_THRESHOLD =  INTC_THRESHOLD_PRIORITYTHRESHOLD;
//	printf("INTC_THRESHOLD = %d\r\n",INTC_THRESHOLD  );

	
	/* Register the default handler for all interrupts */
	for (irq = 0;  irq < 128; irq++)
	{
		 fnRAMVectors[irq] = IntDefaultHandler;
	}
 
}

void IntSystemEnable(int irq)
{
  //  __asm(" dsb");
    
    /* Disable the system interrupt in the corresponding MIR_CLEAR register */
   INTC_MIR_CLEAR(irq >> 0x05)  = (0x01 << (irq & 0x1f));
	printf("IntSystemEnable: %d\n\r", irq);
}



void interrupt_init(int irq,unsigned int priority, unsigned int hostIntRoute)
{

//	int n   = irq >> 4 ;   /* irq/32 */

	/* IntSystemEnable
	 *	Disable the system interrupt in the corresponding MIR_CLEAR register */
    INTC_MIR_CLEAR(irq >> 0x05)   = (0x01 << (irq & 0x1f));

                           
	/*控制时钟和功能时钟设置 默认即可*/
	//INTC_IDLE

	/*关闭保护模式 默认即可*/
	//INTC_PROTECTION

//	printf("INTC_PROTECTION     = %d\n\r", INTC_PROTECTION);


	/*NewIrq_Reset IRQ输出并启用新的IRQ生成*/
	//INTC_CONTROL

	
	/*激活中断号*/
	//INTC_SIR_IRQ 

	 /* irq ===> CPU interface 0 */


	/*提供当前活动IRQ的优先级*/
	//INTC_IRQ_PRIORITY


	/*设置优先级的级别*/
	//INTC_THRESHOLD


	//设置中断号的极性以及
	INTC_ILR(irq) =((priority << 0x2) & 0x1fc) | hostIntRoute ;
	
//	printf("INTC_ILR 	= %d\n\r", INTC_ILR(irq));

	printf("interrupt_init is ok ! \r\n");

}




void register_irq(int irq, irq_func func)
{
	
	printf("register_irq: %d.\n\r", irq);

	if (irq > 0 && irq < 128)
		g_irq_func_array[irq] = func;


	
}



void IntIfClkAutoGateSet(void)
{
    INTC_SYSCONFIG |= INTC_SYSCONFIG_AUTOIDLE; 
}



void IntSoftwareIntClear(int irq)
{
    /* Disable the software interrupt in the corresponding ISR_CLEAR register */
    INTC_ISR_CLEAR(irq >> 0x05) = (0x01 << (irq & 0x1f));
	printf("gic_int_clear %d\r\n",irq); 

}

 void IntSystemDisable(int irq)
 {
 
	// __asm(" dsb");
	 
	 /* Enable the system interrupt in the corresponding MIR_SET register */
	INTC_MIR_SET(irq >> 0x05)  = (0x01 << (irq & 0x1f));
 }


 int getirq(void)
 {
	 return ( INTC_SIR_IRQ &  INTC_SIR_IRQ_ACTIVEIRQ);
 }


 void IntMasterIRQEnable(void)
{
    /* Enable IRQ in CPSR.*/
    CPUirqe();

}
 void IntMasterIRQDisable(void)
 {
	 /* Disable IRQ in CPSR.*/
	 CPUirqd();
 }


 

 void gic_int_clear(int irq)
 {
	 int n	 = irq >> 0x05 ;   /* irq/32 */
	 int bit = irq & 0x1f;	/* irq mod 32 */
 
 
	 /*显示屏蔽前的原始输入状态*/
	 //INTC_ITR(n) |= (1<<bit); 	 // 使能中断	 
	 /*包含中断屏蔽*/
	 //INTC_MIR(1)			 
	 /*包含屏蔽后的IRQ状态*/	 
	 //INTC_PENDING_IRQ
	 INTC_MIR_CLEAR(n) |= (1 << bit);
	 printf("gic_int_clear ok !!! \r\n");	 
 }


void do_irq(int lr)
{
	int irq = getirq();
		
	printf("get_irq: %d, lr = 0x%x\n\r", irq, lr);
	if (g_irq_func_array[irq])
	{
		g_irq_func_array[irq]();
	}
	IntSoftwareIntClear(irq);
	//IntSystemDisable(irq);
	
}




#if 0

int get_irq(void)
{

	    return ((INTC_SIR_IRQ & INTC_SIR_IRQ_SPURIOUSIRQ)  >> INTC_SIR_IRQ_SPURIOUSIRQ_SHIFT);
		/* Disable the system interrupt in the corresponding MIR_CLEAR register */
    //(INTC_MIR_CLEAR(intrNum >> REG_IDX_SHIFT))   = (0x01 << (intrNum & REG_BIT_MASK));
}

/*initialize the interrupt controller*/
void gic_init(void)
{
	/* Reset the ARM interrupt controller */
	INTC_SYSCONFIG = 0x2;
	printf("INTC_SYSSTATUS	   = %d\n\r", INTC_SYSSTATUS);

	/* Wait for the reset to complete */
	INTC_SYSSTATUS |= (0x1 << 0);
	printf("INTC_SYSSTATUS     = %d\n\r", INTC_SYSSTATUS);
	
	/* Enable any interrupt generation by setting priority threshold  通过设置优先级阈值启用任何中断生成*/ 
	INTC_THRESHOLD = 0xff; //屏蔽所有优先级
	printf("INTC_THRESHOLD     = %d\n\r", INTC_THRESHOLD);
 
}


void IntPrioritySet(unsigned int intrNum, unsigned int priority,
                    unsigned int hostIntRoute)
{
   INTC_ILR(intrNum) =((priority << 0x2) & 0x1fc) | hostIntRoute ;
}



/**
 * \brief    Registers an interrupt Handler in the interrupt vector table for
 *           system interrupts. 
 **/
void IntRegister(unsigned int intrNum, void (*fnHandler)(void))
{
    /* Assign ISR */
    fnRAMVectors[intrNum] = fnHandler;
}



/**
 * \brief   This API assigns a priority to an interrupt and routes it to
 *          either IRQ or to FIQ. Priority 0 is the highest priority level
 *          Among the host interrupts, FIQ has more priority than IRQ.
 *
 * \param   intrNum  - Interrupt number
 * \param   priority - Interrupt priority level
 * \param   hostIntRoute - The host interrupt IRQ/FIQ to which the interrupt
 *                         is to be routed.
 *     'priority' can take any value from 0 to 127, 0 being the highest and
 *     127 being the lowest priority.              
 *
 *     'hostIntRoute' can take one of the following values \n
 *             AINTC_HOSTINT_ROUTE_IRQ - To route the interrupt to IRQ \n
 *             AINTC_HOSTINT_ROUTE_FIQ - To route the interrupt to FIQ
 *
 * \return  None.
 *
 **/
void IntPrioritySet(unsigned int intrNum, unsigned int priority,
                    unsigned int hostIntRoute)
{
   		INTC_ILR(intrNum) = ((priority << 0x2)  & 0x1FC)  | hostIntRoute ;
}

 /**
 * \brief	This API enables the system interrupt in AINTC. However, for 
 *			the interrupt generation, make sure that the interrupt is 
 *			enabled at the peripheral level also. 
 * \param	intrNum  - Interrupt number
 **/
void IntSystemEnable(unsigned int intrNum)
{
//	dsb();
	
	/* Disable the system interrupt in the corresponding MIR_CLEAR register */
  INTC_MIR_CLEAR(intrNum >> REG_IDX_SHIFT)   = (0x01 << (intrNum & REG_BIT_MASK));
}



/**
 * \brief  Enables the processor IRQ only in CPSR. Makes the processor to 
 *         respond to IRQs.  This does not affect the set of interrupts 
 *         enabled/disabled in the AINTC.
 */
void IntMasterIRQEnable(void)
{
    /* Enable IRQ in CPSR.*/
    CPUirqe();

}

/**
 * \brief  Disables the processor IRQ only in CPSR.Prevents the processor to 
 *         respond to IRQs.  This does not affect the set of interrupts 
 *         enabled/disabled in the AINTC.
 */
void IntMasterIRQDisable(void)
{
    /* Disable IRQ in CPSR.*/
    CPUirqd();
}

/**
 Returns the status of the interrupts FIQ and IRQ.
 */
unsigned int IntMasterStatusGet(void)
{
    return CPUIntStatus();
}

/**
Clears the software interrupt for the given interrupt number.
 */
void gic_int_clear(unsigned int intrNum)
{
    /* Disable the software interrupt in the corresponding ISR_CLEAR register */
    (INTC_ISR_CLEAR(intrNum >> REG_IDX_SHIFT))  = (0x01 << (intrNum & REG_BIT_MASK));

}

/**
 Returns the raw interrupt status before masking.
 */

unsigned int IntRawStatusGet(unsigned int intrNum)
{
    return (((0 == (  INTC_ITR(intrNum >> REG_IDX_SHIFT))  >> (intrNum & REG_BIT_MASK))& 0x01) ? FALSE : TRUE);
}


/**
 Sets software interrupt for the given interrupt number.
 */
void IntSoftwareIntSet(unsigned int intrNum)
{
    /* Enable the software interrupt in the corresponding ISR_SET register */
    (INTC_ISR_SET(intrNum >> REG_IDX_SHIFT))
                                   = (0x01 << (intrNum & REG_BIT_MASK));

}


#endif

#if 0

/**
 * \brief    Registers an interrupt Handler in the interrupt vector table for
 *           system interrupts. 
 **/
void IntRegister(unsigned int intrNum, void (*fnHandler)(void))
{
    /* Assign ISR */
    fnRAMVectors[intrNum] = fnHandler;
}

/**
 * \brief   Unregisters an interrupt
 * 
 * \param   intrNum - Interrupt Number
 * 
 * Note: Once an interrupt is unregistered it will enter infinite loop once
 * an interrupt occurs
 * 
 **/
void IntUnRegister(unsigned int intrNum)
{
    /* Assign default ISR */
    fnRAMVectors[intrNum] = IntDefaultHandler;
}


/**
 * \brief   This API assigns a priority to an interrupt and routes it to
 *          either IRQ or to FIQ. Priority 0 is the highest priority level
 *          Among the host interrupts, FIQ has more priority than IRQ.
 *
 * \param   intrNum  - Interrupt number
 * \param   priority - Interrupt priority level
 * \param   hostIntRoute - The host interrupt IRQ/FIQ to which the interrupt
 *                         is to be routed.
 *     'priority' can take any value from 0 to 127, 0 being the highest and
 *     127 being the lowest priority.              
 *
 *     'hostIntRoute' can take one of the following values \n
 *             AINTC_HOSTINT_ROUTE_IRQ - To route the interrupt to IRQ \n
 *             AINTC_HOSTINT_ROUTE_FIQ - To route the interrupt to FIQ
 *
 * \return  None.
 *
 **/
void IntPrioritySet(unsigned int intrNum, unsigned int priority,
                    unsigned int hostIntRoute)
{
     INTC_ILR(intrNum)) =
                                 ((priority << INTC_ILR_PRIORITY_SHIFT)
                                   & INTC_ILR_PRIORITY)
                                 | hostIntRoute ;
}

/**
 * \brief   This API enables the system interrupt in AINTC. However, for 
 *          the interrupt generation, make sure that the interrupt is 
 *          enabled at the peripheral level also. 
 * \param   intrNum  - Interrupt number
 **/
void IntSystemEnable(unsigned int intrNum)
{
    __asm(" dsb");
    
    /* Disable the system interrupt in the corresponding MIR_CLEAR register */
    ( INTC_MIR_CLEAR(intrNum >> REG_IDX_SHIFT))
                                   = (0x01 << (intrNum & REG_BIT_MASK));
}

/**
 * \brief   This API disables the system interrupt in AINTC. 
 * \param   intrNum  - Interrupt number
 **/
void IntSystemDisable(unsigned int intrNum)
{

    __asm(" dsb");
    
    /* Enable the system interrupt in the corresponding MIR_SET register */
     ( INTC_MIR_SET(intrNum >> REG_IDX_SHIFT)) 
                                   = (0x01 << (intrNum & REG_BIT_MASK));
}

/**
 * \brief   Sets the interface clock to be free running
 **/
void IntIfClkFreeRunSet(void)
{
    ( INTC_SYSCONFIG)&= ~INTC_SYSCONFIG_AUTOIDLE; 
}

/**
 * \brief   When this API is called,  automatic clock gating strategy is applied
 *          based on the interface bus activity. 
 **/
void IntIfClkAutoGateSet(void)
{
     ( INTC_SYSCONFIG)|= INTC_SYSCONFIG_AUTOIDLE; 
}


/**
 * \brief   Reads the active IRQ number.
 */

unsigned int IntActiveIrqNumGet(void)
{
     ( INTC_SIR_IRQ) &  INTC_SIR_IRQ_ACTIVEIRQ);
}



/**
     Reads the spurious IRQ Flag. Spurious IRQ flag is reflected in both
 *          SIR_IRQ and IRQ_PRIORITY registers of the interrupt controller.
 */
unsigned int IntSpurIrqFlagGet(void)
{
    return ((INTC_SIR_IRQ) 
             & INTC_SIR_IRQ_SPURIOUSIRQ) 
            >> INTC_SIR_IRQ_SPURIOUSIRQ_SHIFT);
}

/**
 * \brief   Enables protection mode for the interrupt controller register access.
 *          When the protection is enabled, the registers will be accessible only
 *          in privileged mode of the CPU.
 */
void IntProtectionEnable(void)
{
   INTC_PROTECTION = INTC_PROTECTION_PROTECTION;
}

/**
   Disables protection mode for the interrupt controller register access.
 *          When the protection is disabled, the registers will be accessible 
 *          in both unprivileged and privileged mode of the CPU.
 */
void IntProtectionDisable(void)
{
    (INTC_PROTECTION) &= ~INTC_PROTECTION_PROTECTION;
}


/**
 * \brief   Enables the free running of input synchronizer clock
 */
void IntSyncClkFreeRunSet(void)
{
     ( INTC_IDLE) &= ~INTC_IDLE_TURBO;
}

/**
   When this API is called, Input synchronizer clock is auto-gated 
 *          based on interrupt input activity
 */

void IntSyncClkAutoGateSet(void)
{
     ( INTC_IDLE) |= INTC_IDLE_TURBO;
}


/**
 * \brief   Enables the free running of functional clock
 */

void IntFuncClkFreeRunSet(void)
{
     ( INTC_IDLE) |= INTC_IDLE_FUNCIDLE;
}


/**
 * \brief   When this API is called, functional clock gating strategy
 *          is applied.
 */
void IntFuncClkAutoGateSet(void)
{
    ( INTC_IDLE) &= ~INTC_IDLE_FUNCIDLE;
}


/**
 * \brief   Returns the currently active IRQ priority level.
 */
unsigned int IntCurrIrqPriorityGet(void)
{
    return ( INTC_IRQ_PRIORITY) 
            & INTC_IRQ_PRIORITY_IRQPRIORITY);
}


/**
Returns the priority threshold.
 */
unsigned int IntPriorityThresholdGet(void)
{
    return ( ( INTC_THRESHOLD) 
            & INTC_THRESHOLD_PRIORITYTHRESHOLD);
}


/**
Sets the given priority threshold value. 
*/
void IntPriorityThresholdSet(unsigned int threshold)
{
    ( INTC_THRESHOLD) = 
                     threshold & INTC_THRESHOLD_PRIORITYTHRESHOLD;
}


/**
 Returns the raw interrupt status before masking.
 */

unsigned int IntRawStatusGet(unsigned int intrNum)
{
    return ((0 == (( ( INTC_ITR(intrNum >> REG_IDX_SHIFT))
                    >> (intrNum & REG_BIT_MASK))& 0x01)) ? FALSE : TRUE);
}


/**
 Sets software interrupt for the given interrupt number.
 */
void IntSoftwareIntSet(unsigned int intrNum)
{
    /* Enable the software interrupt in the corresponding ISR_SET register */
    (INTC_ISR_SET(intrNum >> REG_IDX_SHIFT))
                                   = (0x01 << (intrNum & REG_BIT_MASK));

}


/**
Clears the software interrupt for the given interrupt number.
 */
void IntSoftwareIntClear(unsigned int intrNum)
{
    /* Disable the software interrupt in the corresponding ISR_CLEAR register */
    (INTC_ISR_CLEAR(intrNum >> REG_IDX_SHIFT))  = (0x01 << (intrNum & REG_BIT_MASK));

}


/**
 Returns the IRQ status after masking.
 */
unsigned int IntPendingIrqMaskedStatusGet(unsigned int intrNum)
{
    return ((0 ==(( INTC_PENDING_IRQ(intrNum >> REG_IDX_SHIFT))
                  >> (((intrNum & REG_BIT_MASK)) & 0x01))) ? FALSE : TRUE);
}


/**
 * \brief  Enables the processor IRQ only in CPSR. Makes the processor to 
 *         respond to IRQs.  This does not affect the set of interrupts 
 *         enabled/disabled in the AINTC.
 */
void IntMasterIRQEnable(void)
{
    /* Enable IRQ in CPSR.*/
    CPUirqe();

}


/**
 * \brief  Disables the processor IRQ only in CPSR.Prevents the processor to 
 *         respond to IRQs.  This does not affect the set of interrupts 
 *         enabled/disabled in the AINTC.
 */
void IntMasterIRQDisable(void)
{
    /* Disable IRQ in CPSR.*/
    CPUirqd();
}

/**
  	Enables the processor FIQ only in CPSR. Makes the processor to 
 *         respond to FIQs.  This does not affect the set of interrupts 
 */

void IntMasterFIQEnable(void)
{
    /* Enable FIQ in CPSR.*/
    CPUfiqe();
}


/**
 * \brief  Disables the processor FIQ only in CPSR.Prevents the processor to 
 *         respond to FIQs.  This does not affect the set of interrupts 
 *         enabled/disabled in the AINTC.
 */
void IntMasterFIQDisable(void)
{
    /* Disable FIQ in CPSR.*/
    CPUfiqd();
}


/**
 Returns the status of the interrupts FIQ and IRQ.
 */
unsigned int IntMasterStatusGet(void)
{
    return CPUIntStatus();
}

/**
  Read and save the stasus and Disables the processor IRQ .
    Prevents the processor to respond to IRQs.  
*/

unsigned char IntDisable(void)
{
    unsigned char status;

    /* Reads the current status.*/
    status = (IntMasterStatusGet() & 0xFF);

    /* Disable the Interrupts.*/
    IntMasterIRQDisable();

    return status;
}



/* Restore the processor IRQ only status. This does not affect 		   
	the set of interrupts enabled/disabled in the AINTC. */

void IntEnable(unsigned char  status)
{
    if((status & 0x80) == 0) 
    {
        IntMasterIRQEnable();
    } 
}

#endif




#if 0


static irq_func g_irq_func_array[128];

/**************** *************************************************************
**                 STATIC VARIABLE DEFINITIONS
******************************************************************************/
void (*fnRAMVectors[128])(void);

void CPUirqe(void)
{
    /* Enable IRQ in CPSR */
    asm("    mrs     r0, CPSR\n\t"
        "    bic     r0, r0, #0x80\n\t"
        "    msr     CPSR_c, r0");
}

void IntMasterIRQEnable(void)
{
    /* Enable IRQ in CPSR.*/
    CPUirqe();

}


/**
 * The Default Interrupt Handler.
 *
 * This is the default interrupt handler for all interrupts. It simply returns
 * without performing any operation.
 **/
static void IntDefaultHandler(void)
{
    /* Go Back. Nothing to be done */
    ;
}

void gic_init(void)
{
    unsigned int irq;

    /* Reset the ARM interrupt controller */
    INTC_SYSCONFIG = INTC_SYSCONFIG_SOFTRESET;
 
    /* Wait for the reset to complete */
    while ((INTC_SYSSTATUS  & INTC_SYSSTATUS_RESETDONE) != INTC_SYSSTATUS_RESETDONE);    
  
    /* Enable any interrupt generation by setting priority threshold */ 
   INTC_THRESHOLD =  INTC_THRESHOLD_PRIORITYTHRESHOLD;
//	printf("INTC_THRESHOLD = %d\r\n",INTC_THRESHOLD  );

	
	/* Register the default handler for all interrupts */
	for (irq = 0;  irq < 128; irq++)
	{
		 fnRAMVectors[irq] = IntDefaultHandler;
	}
 
}


void interrupt_init(int irq,unsigned int priority, unsigned int hostIntRoute)
{

//	int n   = irq >> 4 ;   /* irq/32 */

	/* IntSystemEnable
	 *	Disable the system interrupt in the corresponding MIR_CLEAR register */
     INTC_MIR_CLEAR(irq >> 0x05)   = (0x01 << (irq & 0x1f));
	
	/*控制时钟和功能时钟设置 默认即可*/
	//INTC_IDLE

	/*关闭保护模式 默认即可*/
	//INTC_PROTECTION

//	printf("INTC_PROTECTION     = %d\n\r", INTC_PROTECTION);


	/*NewIrq_Reset IRQ输出并启用新的IRQ生成*/
	//INTC_CONTROL

	
	/*激活中断号*/
	//INTC_SIR_IRQ 

	 /* irq ===> CPU interface 0 */


	/*提供当前活动IRQ的优先级*/
	//INTC_IRQ_PRIORITY


	/*设置优先级的级别*/
	//INTC_THRESHOLD


	//设置中断号的极性以及
	INTC_ILR(irq) =((priority << 0x2) & 0x1fc) | hostIntRoute ;
	
//	printf("INTC_ILR 	= %d\n\r", INTC_ILR(irq));

	printf("interrupt_init is ok ! \r\n");

}




void register_irq(int irq, irq_func func)
{
	
	printf("register_irq: %d.\n\r", irq);

	if (irq > 0 && irq < 128)
		g_irq_func_array[irq] = func;


	
}


int get_irq_state(int irq)
{
	
	/*显示屏蔽前的原始输入状态*/
	return ((0 == ((INTC_ITR(irq >> 0x05) >> (irq & 0x1f))& 0x01)) ? FALSE : TRUE);


}

int get_irq(void)
{

	    return ((INTC_SIR_IRQ & INTC_SIR_IRQ_SPURIOUSIRQ)  >> INTC_SIR_IRQ_SPURIOUSIRQ_SHIFT);

}




void gic_int_clear(int irq)
{
	int n   = irq >> 4 ;   /* irq/32 */
	int bit = irq & 0x1f;  /* irq mod 32 */


	/*显示屏蔽前的原始输入状态*/
	//INTC_ITR(n) |= (1<<bit);		// 使能中断		
	/*包含中断屏蔽*/
	//INTC_MIR(1)			
	/*包含屏蔽后的IRQ状态*/		
	//INTC_PENDING_IRQ
	INTC_MIR_CLEAR(n) |= (1 << bit);
	printf("gic_int_clear ok !!! \r\n");	
}





void do_irq(void)
{
	int irq = get_irq();

	
	if (g_irq_func_array[irq])
	{
		g_irq_func_array[irq]();
	}
	
	gic_int_clear(irq);
	
}
#endif

