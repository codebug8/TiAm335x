#include "AM335X_SOC.h"
#include "delay.h"
#include "interrupt.h"
#include "stdio.h"
#include "printf.h"
#include "key.h"
#include "delay.h"


void gpio_set_irq(void)
{

		/*每个输入线启用/禁用用于中断请求生成的上升沿（转换0到1）检测*/
		//GPIO0_RISINGDETECT |= (0x1 << 4);
		//_100ask_printf("GPIO0_RISINGDETECT     = 0x%x\n\r", GPIO0_RISINGDETECT    );
		
		/*每个输入线启用/禁用用于中断请求生成的下降沿（转换1至0）检测。*/
		GPIO0_FALLINGDETECT |= (0x1 << 4);
		_100ask_printf("GPIO0_FALLINGDETECT     = 0x%x\n\r", GPIO0_FALLINGDETECT    );		
		key_irq_enable();
		//key_irq_disable();
}


#if 1
void key_int_irq_test(void)
{
	key_init();	
	gpio_set_irq();
	IntSystemEnable(GPIOINT0A);
	register_irq(GPIOINT0A, key_irq_isr);	
	interrupt_init(GPIOINT0A,0,0);
	IntSystemEnable(GPIOINT0B);
	register_irq(GPIOINT0B, key_irq_isr);	
	interrupt_init(GPIOINT0B,0,0);
}
#endif



void key_init(void)
{
	
	//1.使能GPIO外设时钟. CP468

	CM_WKUP_GPIO0_CLKCTRL  |= (0x2 << 0 | 0x1 << 18);
	printf("CM_WKUP_GPIO0_CLKCTRL	= 0x%x\n\r", CM_WKUP_GPIO0_CLKCTRL );

	//GPIO0_7
	//CONF_ECAP0_IN_PWM0_OUT |=   (0x7 << 0  | 0X1 << 5 );	


	//CONF_GPMC_AD10  |=   (0x7 << 0  | 0X1 << 5 );
	//printf("CONF_GPMC_AD10	= 0x%x\n\r", CONF_GPMC_AD10);
	/*GPIO0_4*/
	CONF_SPI0_D1 |=   (0x7 << 0  | 0X1 << 5 );	
	printf("CONF_SPI0_D1	= 0x%x\n\r", CONF_SPI0_D1 );



	//3.设置输入;CP3731

	//GPIO0_OE &=  ~(0xffffffff); //设置输入
	GPIO0_OE |=  (0x01 << 4);
	printf("GPIO0_OE =  0x%x\n\r", GPIO0_OE );


	//4.设置允许输入位;
	GPIO0_SETDATAOUT &= (0x0 <<4);
	printf("GPIO0_SETDATAOUT =  0x%x\n\r", GPIO0_SETDATAOUT );
	printf("key init ok ! \n\r" );
}




//Use the interrupt method
 void clear_key_irq(void)
{

	GPIO0_IRQSTATUS_0  |= (0x1 << 4);
	printf("GPIO0_IRQSTATUS_0 = 0x%x\r\n",GPIO0_IRQSTATUS_0);

	GPIO0_IRQSTATUS_1  |= (0x1 << 4);
	printf("GPIO0_IRQSTATUS_1 = 0x%x\r\n",GPIO0_IRQSTATUS_1);
	
}


 
void key_irq_enable(void)
{
	GPIO0_IRQSTATUS_SET_0 |= (0x1 << 4); 		
	printf("GPIO0_IRQSTATUS_SET_0     = 0x%x\n\r", GPIO0_IRQSTATUS_SET_0);



	//GPIO0_IRQSTATUS_SET_1 |= (0x1 << 4); 		
//	printf("GPIO0_IRQSTATUS_SET_1     = 0x%x\n\r", GPIO0_IRQSTATUS_SET_1);

	//GPIO0_IRQWAKEN_0  |= (0x1 << 4); 
	//printf("GPIO0_IRQWAKEN_0     = 0x%x\n\r", GPIO0_IRQWAKEN_0);
}

void key_irq_disable(void)
{
	GPIO0_IRQSTATUS_CLR_0 |= (0x1 << 4); 		
	printf("GPIO0_IRQSTATUS_CLR_0     = 0x%x\n\r", GPIO0_IRQSTATUS_CLR_0);



	//GPIO0_IRQSTATUS_SET_1 |= (0x1 << 4); 		
//	printf("GPIO0_IRQSTATUS_SET_1     = 0x%x\n\r", GPIO0_IRQSTATUS_SET_1);

	//GPIO0_IRQWAKEN_0  |= (0x1 << 4); 
	//printf("GPIO0_IRQWAKEN_0     = 0x%x\n\r", GPIO0_IRQWAKEN_0);
}



void key_irq_isr(void)
{	
	//_100ask_printf("GPIO0_IRQSTATUS_0   = 0x%x\n\r", GPIO0_IRQSTATUS_0);	
	if (GPIO0_DATAIN  & (0x1 << 4))  
	{	
		
		 _100ask_printf("==================key irq: release!===============\n\r");
		 _100ask_printf("GPIO0_IRQSTATUS_0   = 0x%x\n\r", GPIO0_IRQSTATUS_0);		
		delay(1000000);
	
	
	}
	else 
	{	

		_100ask_printf("==================key irq: push !===============\n\r");
		_100ask_printf("GPIO0_IRQSTATUS_0   = 0x%x\n\r", GPIO0_IRQSTATUS_0);
		 delay(1000000);
	}	
	clear_key_irq();

	//key_irq_disable();
	//IntMasterIRQDisable();
	
}





#if 0
	printf("enter key_init\n");
	val = CONF_SPI0_D1;
	printf("get reg\n");
	printf("CONF_SPI0_D1  = %d\n\r", val );
	printf("ok\n");
#endif

