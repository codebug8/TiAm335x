﻿#include "uart.h"
#include "qspi.h"
#include "oled.h"
#include "AM437X/AM437X_SOC.h"
#include "qspi.h"
void mdelay(int times);
int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val);



void mdelay(int times)
{
	volatile int i, j;
	for(j = 0 ; j < times; j++ )
		{	for(i=0; i < 100000; i++ );
			i = i+1;
		}
}

int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val)
{
	volatile unsigned  int  reg=reg_addr;	
	unsigned  int  tmp=0;//volatile unsigned  int  tmp=0;
	
	do
	{
		tmp = reg;
		tmp = tmp & (bits); 
	}
	while(expected_val !=  tmp);//判断

	return 0;
}

	





int main()
{
    char c;
    char str[200];
    int i;
	int address;
	int data;
    
    uart_init();   // 波特率115200，8N1(8个数据位，无校验位，1个停止位)
	
	
		/* 使用SPI0控制器*/
	
		
		/*配置相应的引脚为SPI0*/
		CTRL_CONF_SPI0_SCLK	 &= ~(0x7 <<0 );
		
		CTRL_CONF_SPI0_SCLK |= (0x0 << 0);
		_100ask_printf("CTRL_CONF_SPI0_SCLK 0x%x\r\n",CTRL_CONF_SPI0_SCLK);
		
		 CTRL_CONF_SPI0_D0 &= ~(0x7 <<0 );
		
		CTRL_CONF_SPI0_D0	|= (0x0 << 0);	//是MOSI
		_100ask_printf("CTRL_CONF_SPI0_D0 0x%x\r\n",CTRL_CONF_SPI0_D0);
		
		CTRL_CONF_SPI0_CS0  &= ~(0x7 <<0 );
		
		CTRL_CONF_SPI0_CS0	|= (0x0 << 0);	
		_100ask_printf("CTRL_CONF_SPI0_CS0 0x%x\r\n",CTRL_CONF_SPI0_CS0);
	
		CTRL_CONF_SPI0_D1	&= ~(0x7 <<  0 );
		_100ask_printf("--------CTRL_CONF_SPI0_D1------- 0x%x\r\n",CTRL_CONF_SPI0_D1);

		CTRL_CONF_SPI0_D1	|= (0x0 << 0);
		_100ask_printf("-------------------------------CTRL_CONF_SPI0_D1 0x%x\r\n",CTRL_CONF_SPI0_D1);
		//把SPI0的引脚配置为SPI模式
	
	


		//配置mcspi的总时钟源
		PRCM_CM_CLKOUT2_CTRL |= (0x2 << 8 | 0x3 << 4 | 0x3 <<0);

		_100ask_printf("PRCM_CM_CLKOUT2_CTRL 0x%x\r\n",PRCM_CM_CLKOUT2_CTRL);
	
		PRCM_CM_PER_SPI0_CLKCTRL |=  (0x0 << 16 | 0x2 << 0);//配置SPI0的时钟源
		mdelay(1);
		_100ask_printf("PRCM_CM_PER_SPI0_CLKCTRL 0x%x\r\n",PRCM_CM_PER_SPI0_CLKCTRL);
	
		
	
	
		
	/*1 硬件强制复位*/
	
		McSPI0->HL_SYSCONFIG &= ~(0x1 << 0);
	_100ask_printf("HL_SYSCONFIG--> 0x%x\r\n",McSPI0->HL_SYSCONFIG);
		mdelay(1);
		McSPI0->HL_SYSCONFIG |= (0x1 << 0);
	_100ask_printf("HL_SYSCONFIG 0x%x\r\n",McSPI0->HL_SYSCONFIG);
	

/*2 读取相关模块状态 MCSPI_SYSSTS */
		mdelay(2);
		_100ask_printf("McSPI0->MCSPI_SYSSTS------> 0x%x\r\n",McSPI0->SYSSTS);
		

/*3 模块配置	  MCSPI_MODULCTRL
			   bit 8	配置tx rx管理数据
			   bit 7	0h（R / W）=禁用多个字访问 	
			   bit 6:4	0h（R / W）=第一个spi传输没有延迟。
			   bit 3	0h（R / W）=功能模式
			   bit 2	1h（R / W）=从器件 - 模块接收SPICLK和SPIEN [3：0]
			   bit 1	0h（R / W）= 4PinMode：SPIEN用作芯片选择。
			   bit 0	1h（R / W）=在主模式下只能使用一个通道。 该位必须设置为强制SPIEN模式
			*/
			McSPI0->MODULCTRL &= ~(  0x0 << 2);
			mdelay(1);
			_100ask_printf("MODULCTRL --> 0x%x\r\n",McSPI0->MODULCTRL);
			McSPI0->MODULCTRL |= ( 0x0 << 2 );
			_100ask_printf("MODULCTRL --> 0x%x\r\n",McSPI0->MODULCTRL);
			mdelay(1);

		
		
		
		//启用唤醒功能
		McSPI0->SYSCONFIG |= (0x3 << 8);//[8:9]保持时钟功能

/*
		_100ask_printf("SYSCONFIG--> 0x%x\r\n",McSPI0->SYSCONFIG);
		McSPI0->SYSCONFIG |= (0x3 << 3);//[3:4]则模块将根据其内部活动切换到空闲模式，并且如果设置了位MCSPI_SYSCONFIG [EnaWakeUp]，则可以使用唤醒功能。

		_100ask_printf("SYSCONFIG--> 0x%x\r\n",McSPI0->SYSCONFIG);
		McSPI0->SYSCONFIG |= (0x1 << 2); //[2]唤醒功能使能
		_100ask_printf("SYSCONFIG--> 0x%x\r\n",McSPI0->SYSCONFIG);

*/
		
	
		/*3.1 启用通道0的所有状态IRQSTS
		bit 16	1h（R）=事件正在等待 当在字段MCSPI_CH0CONF [SPIENSLV]中编程的SPIEN线上检测到有效控制信号时，从机模式唤醒事件 
		bit 3	1h（R）=事件正在等待	接收器寄存器溢出（仅限从模式）
		bit 2	1h（R）=事件正在等待 接收器寄存器满或几乎满
		bit 1	1h（R）=事件正在等待 发射机寄存器下溢
		bit 0	1h（R）=事件正在等待		 变送器寄存器为空或几乎为空
		*/
		
		McSPI0->IRQSTS &= ~(0x1 << 16 | 0x1 << 3 | 0x1 << 2 | 0x1 << 1 | 0x1 << 0);
		mdelay(1);
		_100ask_printf("IRQSTS --> 0x%x\r\n",McSPI0->IRQSTS);
		McSPI0->IRQSTS |= (0x1 << 16 | 0x1 << 3 | 0x1 << 2 | 0x1 << 1 | 0x1 << 0);
		_100ask_printf("IRQSTS --> 0x%x\r\n",McSPI0->IRQSTS);
		mdelay(1);
		_100ask_printf("IRQSTS --> 0x%x\r\n",McSPI0->IRQSTS);

		/*3.2 启用模块 IRQEN
		bit 16		1h（R / W）=允许中断 唤醒事件中断在从站模式中，当在场中编程的SPIEN线上检测到有效控制信号时，使能MCSPI_CH0CONF [SPIENSLV]
		bit 1		1h（R / W）=允许中断	发送器寄存器下溢中断使能
		bit 0		1h（R / W）=允许中断	发送器寄存器空中断使能*/
		
		McSPI0->IRQEN &= ~(0x1 << 16 |0x1 << 3 | 0x1 << 2 |  0x1 << 1 | 0x1 << 0);
		mdelay(1);
		McSPI0->IRQEN |= (0x1 << 16 |0x1 << 3 | 0x1 << 2 |  0x1 << 1 | 0x1 << 0);
		_100ask_printf("IRQEN --> 0x%x\r\n",McSPI0->IRQEN);
		
		/*3.3 启用或者唤醒使能 WAKEUPEN
		bit 0			1h（R / W）=如果设置了全局控制位MCSPI_SYSCONF [EnaWakeUp]，则允许事件唤醒系统。
		*/
		McSPI0->WAKEUPEN &= ~(0x1 << 0);
		McSPI0->WAKEUPEN |= (0x1 << 0);
		_100ask_printf("WAKEUPEN --> 0x%x\r\n",McSPI0->WAKEUPEN);


		/*3.4 检查系统的互联性*/
		McSPI0->SYST &= ~(0x1 << 7 |  0x0 << 6 | 0x0 << 4); 
		_100ask_printf("SYST --> 0x%x\r\n",McSPI0->SYST);
		mdelay(1);
		McSPI0->SYST &= ~(0x1 << 7 |  0x0 << 6 | 0x0 << 4); 
		_100ask_printf("SYST --> 0x%x\r\n",McSPI0->SYST);
		/*4 通道0 配置 CH0CONF mr表示默认
		bit[13:12]	2h（R / W）=仅发送模式
		bit 6		1h（R / W）= SPIEN在激活状态下保持低电平
		bit[5:2]	0h（R / W）= 1
		bit 1		1h（R / W）= SPICLK在激活状态期间保持低电平时，SPICLK保持为高电平
		bit 0		1h（R / W）=数据被锁存在SPICLK的偶数边。
		*/
		McSPI0->CH0CONF &= ~(0x2 << 12 | 0x1 << 1 | 0x1 <<0);
		mdelay(1);
		_100ask_printf("CH0CONF --> 0x%x\r\n",McSPI0->CH0CONF);	
		McSPI0->CH0CONF |= (0x2 << 12 | 0x1 << 1 | 0x1 <<0);
		_100ask_printf("CH0CONF --> 0x%x\r\n",McSPI0->CH0CONF);	
		mdelay(1);
		/*5 读取相关状态信息  CH0STAT */
	
		_100ask_printf("Channel_Stat --> 0x%x\r\n",McSPI0->CH0STAT);	
	
		/*6 使能通道0 CH0CTRL 
		bit[15:8]		0h（R / W）=时钟比为CLKD + 1 mr
		bit 0			1h（R / W）=通道“I”有效
		*/
		McSPI0->CH0CTRL &= ~(0x1 << 0);
		mdelay(1);
		McSPI0->CH0CTRL |= (0x1 << 0);
	
		_100ask_printf("CH0CTRL --> 0x%x\r\n",McSPI0->CH0CTRL);



		McSPI0->TX0 = (0x0);
		_100ask_printf("TX0 --> 0x%x\r\n",McSPI0->TX0);


		McSPI0->TX0 = (0x10);
		_100ask_printf("TX0 --> 0x%x\r\n",McSPI0->TX0);

		McSPI0->TX0 = (0x80);
		_100ask_printf("TX0 --> 0x%x\r\n",McSPI0->TX0);
	
	
	
	
	

	

  	 SPIInit();
    OLEDInit();
    OLEDPrint(0,0,"www.100ask.net, 100ask.taobao.com");
    
    
    while (1)
    {
        
        _100ask_printf("Enter your selection: ");

      
    	}
    return 0;
}
