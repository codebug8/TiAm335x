#include "AM335X_SOC.h"
//#include "led.h"
#include "key.h"
#include "interrupt.h"
#include "delay.h"
#include "uart.h"
#include "printf.h"


int  main()
{

	uart_init();
	printf("uart  init.\n\r");
	gic_init();
	//IntIfClkAutoGateSet();	
	
	key_init(); 
	gpio_set_irq();
	IntSystemEnable(GPIOINT0A);
	interrupt_init(GPIOINT0A,0,0);
	register_irq(GPIOINT0A, key_irq_isr);		
	//delay(10000000);	

	//IntMasterIRQDisable();


	while(1)
	{
		printf("WORK...\n\r"); 
		//delay(10000000);		
		//
	}
	
	return 0;
	
}




#if 0

//extern void  uart_PutChar(unsigned char  c);

extern char hex_tab[];

void puthex(unsigned int val)
{
	/* 0x1234abcd */
	int i;
	int j;
	
	uart_PutChar('0');
	uart_PutChar('x');


	for (i = 0; i < 8; i++)
	{
		j = (val >> ((7-i)*4)) & 0xf;
		if ((j >= 0) && (j <= 9))
			uart_PutChar('0' + j);
		else
			uart_PutChar('A' + j - 0xa);
		
	}
	
}
#endif
