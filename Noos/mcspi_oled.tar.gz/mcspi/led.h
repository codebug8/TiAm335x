#ifndef  __LED_H__
#define  __LED_H__

extern void led_init(void);

#endif


