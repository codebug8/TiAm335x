#ifndef  __AM335X_INT_H__
#define  __AM335X_INT_H__
#include  "AM335X_DataType.h"
#include  "AM335X_Mapping.h"

#define EMUINT 0    	
#define COMMTX 1    	
#define COMMRX 2    	
#define BENCH 3    	
#define ELM_IRQ 4    	
   	
#define NMI 7    	
 	
#define L3DEBUG 9    	
#define L3APPINT 10   	
#define PRCMINT 11   	
#define EDMACOMPINT 12   	
#define EDMAMPERR 13   	
#define EDMAERRINT 14   	
	
#define ADC_TSC_GENINT 16   	
#define USBSSINT 17   	
#define USBINT0 18   	
#define USBINT1 19   	
#define PRU_ICSS_EVTOUT0 20   	
#define PRU_ICSS_EVTOUT1 21   	
#define PRU_ICSS_EVTOUT2 22   	
#define PRU_ICSS_EVTOUT3 23   	
#define PRU_ICSS_EVTOUT4 24   	
#define PRU_ICSS_EVTOUT5 25   	
#define PRU_ICSS_EVTOUT6 26   	
#define PRU_ICSS_EVTOUT7 27   	
#define MMCSD1INT 28   	
#define MMCSD2INT 29   	
#define I2C2INT 30   	
#define eCAP0INT 31   	
#define GPIOINT2A 32   	
#define GPIOINT2B 33   	
#define USBWAKEUP 34   	
 	
#define LCDCINT 36   	
#define GFXINT 37   	
 	
#define ePWM2INT 39   	
#define PGSWRXTHR0 40   	
#define PGSWRXINT0  41   	
#define PGSWTXINT0 42   	
#define PGSWMISC0 43   	
#define UART3INT 44   	
#define UART4INT 45   	
#define UART5INT 46   	
#define eCAP1INT 47   	
 	
#define DCAN0_INT0 52   	
#define DCAN0_INT1 53   	
#define DCAN0_PARITY 54   	
#define DCAN1_INT0 55   	
#define DCAN1_INT1 56   	
#define DCAN1_PARITY 57   	
#define ePWM0_TZINT 58   	
#define ePWM1_TZINT 59   	
#define ePWM2_TZINT 60   	
#define eCAP2INT 61   	
#define GPIOINT3A 62   	
#define GPIOINT3B 63   	
#define MMCSD0INT 64   	
#define McSPI0INT 65   	
#define TINT0 66   	
#define TINT1_1MS 67   	
#define TINT2 68   	
#define TINT3 69   	
#define I2C0INT 70   	
#define I2C1INT 71   	
#define UART0INT 72   	
#define UART1INT 73   	
#define UART2INT 74   	
#define RTCINT 75   	
#define RTCALARMINT 76   	
#define MBINT0 77   	
#define M3_TXEV 78   	
#define eQEP0INT 79   	
#define MCATXINT0 80   	
#define MCARXINT0 81   	
#define MCATXINT1 82   	
#define MCARXINT1 83   	
	
#define ePWM0INT 86   	
#define ePWM1INT 87   	
#define eQEP1INT 88   	
#define eQEP2INT 89   	
#define DMA_INTR_PIN2 90   	
#define WDT1INT  91   	
#define TINT4 92   	
#define TINT5 93   	
#define TINT6 94   	
#define TINT7 95   	
#define GPIOINT0A 96   	
#define GPIOINT0B 97   	
#define GPIOINT1A 98   	
#define GPIOINT1B 99   	
#define GPMCINT 100 	
#define DDRERR0 101 	
	
#define TCERRINT0 112 	
#define TCERRINT1 113 	
#define TCERRINT2 114 	
#define ADC_TSC_PENINT 115 	
	
#define SMRFLX_MPU   120 	
#define SMRFLX_Core 121 	
	
#define DMA_INTR_PIN0 123 	
#define DMA_INTR_PIN1 124 	
#define McSPI1INT 125 	
	


#define INTC_REVISION 		(*(volatile unsigned long *)(INTCPS + 0x0)) /* This register contains the IP revision code */
#define INTC_SYSCONFIG 		(*(volatile unsigned long *)(INTCPS + 0x10))/* This register controls the various parameters of the OCP interface */
#define INTC_SYSSTATUS 		(*(volatile unsigned long *)(INTCPS + 0x14))/* This register provides status information about the module*/
#define INTC_SIR_IRQ 		(*(volatile unsigned long *)(INTCPS + 0x40))/* This register supplies the currently active IRQ interrupt number.*/
#define INTC_SIR_FIQ 		(*(volatile unsigned long *)(INTCPS + 0x44))/* This register supplies the currently active FIQ interrupt numbe*/
#define INTC_CONTROL 		(*(volatile unsigned long *)(INTCPS + 0x48))/* This register contains the new interrupt agreement bits */
#define INTC_PROTECTION 	(*(volatile unsigned long *)(INTCPS + 0x4c))/* This register controls protection of the other registers. This register can only be accessed in priviledged
mode, regardless of the curent value of the protection bit*/

#define INTC_IDLE  			(*(volatile unsigned long *)(INTCPS + 0x50))/* This register controls the clock auto-idle for the functional clock and the input synchronisers*/
#define INTC_IRQ_PRIORITY 	(*(volatile unsigned long *)(INTCPS + 0x60))/* This register supplies the currently active IRQ priority level*/
#define INTC_FIQ_PRIORITY 	(*(volatile unsigned long *)(INTCPS + 0x64))/* This register supplies the currently active FIQ priority level*/
#define INTC_THRESHOLD 		(*(volatile unsigned long *)(INTCPS + 0x68))/* This register sets the priority threshold */
#define INTC_SICR  			(*(volatile unsigned long *)(INTCPS + 0x6c))/* */                                                            

#define INTC_SCR(n) 		(*(volatile unsigned long *)(INTCPS + 0x70  + ((n) * 0x04)))


#define INTC_ITR(n) 		(*(volatile unsigned long *)(INTCPS + 0x80  + ((n) * 0x20)))/* This register shows the raw interrupt input status before masking   */
#define INTC_MIR(n) 		(*(volatile unsigned long *)(INTCPS + 0x84  + ((n) * 0x20)))/* This register contains the interrupt mask  */


#define INTC_MIR_CLEAR(n) 	(*(volatile unsigned long *)(INTCPS + 0x88  + ((n) * 0x20)))/* This register is used to clear the interrupt mask bits. */


#define INTC_MIR_SET(n) 	(*(volatile unsigned long *)(INTCPS + 0x8c  + ((n) * 0x20)))/* This register is used to set the interrupt mask bits.  */   

#define INTC_ISR_SET(n) 	(*(volatile unsigned long *)(INTCPS + 0x90  + ((n) * 0x20)))/* This register is used to set the software interrupt bits. It is also used to read the currently active software
interrupts.  */      


#define INTC_ISR_CLEAR(n) 	(*(volatile unsigned long *)(INTCPS + 0x94  + ((n) * 0x20)))/* This register is used to clear the software interrupt bits  */


#define INTC_PENDING_IRQ(n) (*(volatile unsigned long *)(INTCPS + 0x98  + ((n) * 0x20)))/* This register contains the IRQ status after masking  */
#define INTC_PENDING_FIQ(n) (*(volatile unsigned long *)(INTCPS + 0x9c  + ((n) * 0x20)))/* This register contains the FIQ status after masking  */
#define INTC_ILR(n)  		(*(volatile unsigned long *)(INTCPS + 0x100 + ((n) * 0x04)))/* The INTC_ILRx registers contain the priority for the interrupts and the FIQ/IRQ steering.  */




#if 0
#define    INTC_REVISION		(*(volatile unsigned long *)(INTCPS   +	   	0x0 ))
#define    INTC_SYSCONFIG       (*(volatile unsigned long *)(INTCPS   +     0x10))
#define    INTC_SYSSTATUS       (*(volatile unsigned long *)(INTCPS   +     0x14))
#define    INTC_SIR_IRQ         (*(volatile unsigned long *)(INTCPS   +     0x40))
#define    INTC_SIR_FIQ         (*(volatile unsigned long *)(INTCPS   +     0x44))
#define    INTC_CONTROL         (*(volatile unsigned long *)(INTCPS   +     0x48))
#define    INTC_PROTECTION      (*(volatile unsigned long *)(INTCPS   +     0x4C))
#define    INTC_IDLE            (*(volatile unsigned long *)(INTCPS   +     0x50))
#define    INTC_IRQ_PRIORITY    (*(volatile unsigned long *)(INTCPS   +     0x60))
#define    INTC_FIQ_PRIORITY    (*(volatile unsigned long *)(INTCPS   +     0x64))
#define    INTC_THRESHOLD       (*(volatile unsigned long *)(INTCPS   +     0x68))

#define    INTC_ITR0            (*(volatile unsigned long *)(INTCPS   +     0x80))
#define    INTC_MIR0            (*(volatile unsigned long *)(INTCPS   +     0x84))
#define    INTC_MIR_CLEAR0      (*(volatile unsigned long *)(INTCPS   +     0x88))
#define    INTC_MIR_SET0        (*(volatile unsigned long *)(INTCPS   +     0x8C))
#define    INTC_ISR_SET0        (*(volatile unsigned long *)(INTCPS   +     0x90))
#define    INTC_ISR_CLEAR0      (*(volatile unsigned long *)(INTCPS   +     0x94))
#define    INTC_PENDING_IRQ0    (*(volatile unsigned long *)(INTCPS   +     0x98))
#define    INTC_PENDING_FIQ0    (*(volatile unsigned long *)(INTCPS   +     0x9C))

#define    INTC_ITR1            (*(volatile unsigned long *)(INTCPS   +     0xA0))
#define    INTC_MIR1            (*(volatile unsigned long *)(INTCPS   +     0xA4))
#define    INTC_MIR_CLEAR1      (*(volatile unsigned long *)(INTCPS   +     0xA8))
#define    INTC_MIR_SET1        (*(volatile unsigned long *)(INTCPS   +     0xAC))
#define    INTC_ISR_SET1        (*(volatile unsigned long *)(INTCPS   +     0xB0))
#define    INTC_ISR_CLEAR1      (*(volatile unsigned long *)(INTCPS   +     0xB4))
#define    INTC_PENDING_IRQ1    (*(volatile unsigned long *)(INTCPS   +     0xB8))
#define    INTC_PENDING_FIQ1    (*(volatile unsigned long *)(INTCPS   +     0xBC))

#define    INTC_ITR2            (*(volatile unsigned long *)(INTCPS   +     0xC0))
#define    INTC_MIR2            (*(volatile unsigned long *)(INTCPS   +     0xC4))
#define    INTC_MIR_CLEAR2      (*(volatile unsigned long *)(INTCPS   +     0xC8))
#define    INTC_MIR_SET2        (*(volatile unsigned long *)(INTCPS   +     0xCC))
#define    INTC_ISR_SET2        (*(volatile unsigned long *)(INTCPS   +     0xD0))
#define    INTC_ISR_CLEAR2      (*(volatile unsigned long *)(INTCPS   +     0xD4))
#define    INTC_PENDING_IRQ2    (*(volatile unsigned long *)(INTCPS   +     0xD8))
#define    INTC_PENDING_FIQ2    (*(volatile unsigned long *)(INTCPS   +     0xDC))

#define    INTC_ITR3            (*(volatile unsigned long *)(INTCPS   +     0xE0))
#define    INTC_MIR3            (*(volatile unsigned long *)(INTCPS   +     0xE4))
#define    INTC_MIR_CLEAR3      (*(volatile unsigned long *)(INTCPS   +     0xE8))
#define    INTC_MIR_SET3        (*(volatile unsigned long *)(INTCPS   +     0xEC))
#define	   INTC_ISR_SET3		(*(volatile unsigned long *)(INTCPS   +	   0xF0))
#define    INTC_ISR_CLEAR3      (*(volatile unsigned long *)(INTCPS   +     0xF4))
#define    INTC_PENDING_IRQ3    (*(volatile unsigned long *)(INTCPS   +     0xF8))
#define    INTC_PENDING_FIQ3    (*(volatile unsigned long *)(INTCPS   +     0xFC))
#endif

#endif 








