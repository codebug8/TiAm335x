

#include "AM437X/AM437X_SOC.h"
#include "qspi.h"
void delay(int times);
void int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val);
void SPI_Set_CLK(void);

void delay(int times)
{
	volatile int i, j;
	for(j = 0 ; j < times; j++ )
		{	for(i=0; i < 100000; i++ );
			i = i+1;
		}
}



void spi0_irq_endable (void)
{	
	/*3.1 启用通道0的所有状态IRQSTS
	bit 16	1h（R）=事件正在等待 当在字段MCSPI_CH0CONF [SPIENSLV]中编程的SPIEN线上检测到有效控制信号时，从机模式唤醒事件 
	bit 3	1h（R）=事件正在等待	接收器寄存器溢出（仅限从模式）
	bit 2	1h（R）=事件正在等待 接收器寄存器满或几乎满
	bit 1	1h（R）=事件正在等待 发射机寄存器下溢
	bit 0	1h（R）=事件正在等待		 变送器寄存器为空或几乎为空
	*/

	_100ask_printf("McSPI0->IRQSTS=---> 0x%x\r\n",McSPI0->IRQSTS);

	/*3.2 启用模块 IRQEN
	bit 16		1h（R / W）=允许中断 唤醒事件中断在从站模式中，当在场中编程的SPIEN线上检测到有效控制信号时，使能MCSPI_CH0CONF [SPIENSLV]
	bit 1		1h（R / W）=允许中断	发送器寄存器下溢中断使能
	bit 0		1h（R / W）=允许中断	发送器寄存器空中断使能
	*/
	McSPI0->IRQEN |= (0x1 << 16 | 0x1 << 1 | 0x1 << 0);

	/*3.3 启用或者唤醒使能 WAKEUPEN
	bit 0  			1h（R / W）=如果设置了全局控制位MCSPI_SYSCONF [EnaWakeUp]，则允许事件唤醒系统。
	*/
	McSPI0->WAKEUPEN |= (0x1 << 0);
}


/* 使用SPI0控制器*/

static void SPI0_GPIO_Init(void)
{
		/*配置相应的引脚为SPI0*/
		CTRL_CONF_SPI0_SCLK	 &= ~(0x7 <<0 );
		
		CTRL_CONF_SPI0_SCLK |= (0x0 << 0);
		_100ask_printf("CTRL_CONF_SPI0_SCLK 0x%x\r\n",CTRL_CONF_SPI0_SCLK);
		
		 CTRL_CONF_SPI0_D0 &= ~(0x7 <<0 );
		
		CTRL_CONF_SPI0_D0	|= (0x0 << 0);	//是MOSI
		_100ask_printf("CTRL_CONF_SPI0_D0 0x%x\r\n",CTRL_CONF_SPI0_D0);
		
		CTRL_CONF_SPI0_CS0  &= ~(0x7 <<0 );
		
		CTRL_CONF_SPI0_CS0	|= (0x0 << 0);	
		_100ask_printf("CTRL_CONF_SPI0_CS0 0x%x\r\n",CTRL_CONF_SPI0_CS0);
	
		CTRL_CONF_SPI0_D1	&= ~(0x7 <<  0 );
		_100ask_printf("--------CTRL_CONF_SPI0_D1------- 0x%x\r\n",CTRL_CONF_SPI0_D1);

		CTRL_CONF_SPI0_D1	|= (0x0 << 0);
		_100ask_printf("-------------------------------CTRL_CONF_SPI0_D1 0x%x\r\n",CTRL_CONF_SPI0_D1);
		//把SPI0的引脚配置为SPI模式


}


static void SPI_Set_CLK(void)
{
	
		//配置mcspi的总时钟源
		PRCM_CM_CLKOUT2_CTRL |= (0x2 << 8 | 0x3 << 4 | 0x3 <<0);

		_100ask_printf("PRCM_CM_CLKOUT2_CTRL 0x%x\r\n",PRCM_CM_CLKOUT2_CTRL);
	
		PRCM_CM_PER_SPI0_CLKCTRL |=  (0x0 << 16 | 0x2 << 0);//配置SPI0的时钟源
		mdelay(1);
		_100ask_printf("PRCM_CM_PER_SPI0_CLKCTRL 0x%x\r\n",PRCM_CM_PER_SPI0_CLKCTRL);

}


static void SPI_Sysconfig(void)
{


		
		/*1 硬件强制复位*/
		
		McSPI0->HL_SYSCONFIG &= ~(0x1 << 0);
		_100ask_printf("HL_SYSCONFIG--> 0x%x\r\n",McSPI0->HL_SYSCONFIG);
			mdelay(2);
		_100ask_printf("HL_SYSCONFIG 0x%x\r\n",McSPI0->HL_SYSCONFIG);
		
	
	/*2 读取相关模块状态 MCSPI_SYSSTS */
			mdelay(2);
	_100ask_printf("McSPI0->MCSPI_SYSSTS------> 0x%x\r\n",McSPI0->SYSSTS);
			


	/*3 模块配置      MCSPI_MODULCTRL
	   bit 8    配置tx rx管理数据
	   bit 7    0h（R / W）=禁用多个字访问		
	   bit 6:4  0h（R / W）=第一个spi传输没有延迟。
	   bit 3 	0h（R / W）=功能模式
	   bit 2	1h（R / W）=从器件 - 模块接收SPICLK和SPIEN [3：0]
	   bit 1	0h（R / W）= 4PinMode：SPIEN用作芯片选择。
	   bit 0	1h（R / W）=在主模式下只能使用一个通道。 该位必须设置为强制SPIEN模式
	*/
	McSPI0->MODULCTRL |= (0x0 << 8 | 0x0 << 7 | 0x0 << 4 | 0x0 << 3 | 0x1 << 2 | 0x0 << 1 | 0x1 << 0);


	

	/*4 通道0 配置 CH0CONF mr表示默认
	bit 29		0h（R / W）=两个 mr
	bit 28 		0h（R / W）=缓冲区不用于接收数据。mr
	bit 27		1h（R / W）=缓冲区用于传输数据。mr
	bit[26:25]  0h（R / W）= 0.5时钟周期 mr
	bit 24		1h（R / W）= SPI传输期间，起始位极性保持为1.mr
	bit 23		0h（R / W）=由WL位字段指定的默认SPI传输长度 mr
	bit[22:21]  0h（R / W）=仅在SPIEN [0]  mr
	bit 20		0h（R / W）=当MCSPI_CHCONF（i）[EPOL] = 0时，写入0将SPIEN线驱动为低电平，并且当MCSPI_CHCONF（i）[EPOL] = 1时，将其驱动为高电平。
	bit 19		0h（R / W）=禁用Turbo（推荐用于单个SPI字传输）mr
	bit 18		1h（R / W）=数据线1（SPIDAT [1]）被选择用于接收 mr
	bit 17		1h（R / W）=数据线1上无传输（SPIDAT [1]） mr
	bit 16		0h（R / W）=数据线0（SPIDAT [0]）选择发送 mr
	bit 15		0h（R / W）=禁止DMA读请求 mr
	bit 14		0h（R / W）=禁止DMA写请求 mr
	bit[13:12]  2h（R / W）=仅发送模式
	bit[11:7]	0h保留 mr
	bit 6		1h（R / W）= SPIEN在激活状态下保持低电平
	bit[5:2]	0h（R / W）= 1
	bit 1		1h（R / W）= SPICLK在激活状态期间保持低电平时，SPICLK保持为高电平
	bit 0		1h（R / W）=数据被锁存在SPICLK的偶数边。
	*/
	McSPI0->CH0CONF |= (0x2 << 12 | 0x1 << 6 | 0x1 << 2 | 0x1 << 1 | 0x1 <<0);
	
	/*5 读取相关状态信息  CH0STAT */

	_100ask_printf("Channel_Stat --> 0x%x\r\n",McSPI0->CH0STAT);	

	/*6 使能通道0 CH0CTRL 
	bit[15:8]		0h（R / W）=时钟比为CLKD + 1 mr
	bit 0			1h（R / W）=通道“I”有效
	*/
	McSPI0->CH0CTRL |= (0x1 << 0);


}



 void SPISendByte(unsigned char val)
{
    int i;
    for (i = 0; i < 8; i++)
    {
		
        MCSPI0->Tx0 &= 0x80;
        val <<= 1;
    }
    
}

void SPIInit(void)
{
    /* 初始化引脚 */
    SPI0_GPIO_Init();
	SPI_Set_CLK();
	
	SPI_Sysconfig();
	
}



/*********************************************************************************

   *Function:     loop_judge_register_bits

   *Description： 循环判断某个寄存器的值为多少

   *Input:        寄存器地址，哪些bit位，期待值

   *Output:       \

   *Return:       0

   *Others:       \

**********************************************************************************/

int  loop_judge_register_bits(unsigned  int reg_addr, unsigned  int bits, unsigned  int expected_val)

{

	volatile unsigned  int  reg=reg_addr;	

	unsigned  int  tmp=0;//volatile unsigned  int  tmp=0;

	

	do

	{

		tmp = reg;

		tmp = tmp & (bits); 

	}

	while(expected_val !=  tmp);//判断



	return 0;

}


