#ifndef _SOC_AM335X_H_
#define _SOC_AM335X_H_
//#include "soc_am437x.h"


#include  "AM335X_Mapping.h"
#include  "AM335X_CLock_Module.h"
#include  "AM335X_Control.h"
#include  "AM335X_GPIO.h"
#include  "AM335X_Uart.h"
#include  "AM335X_Timer.h"

#endif
